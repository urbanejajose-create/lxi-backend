<?php
/**
 * LXI Theme Functions
 * 
 * @package LXI_Theme
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function lxi_theme_setup() {
    // Add title tag support
    add_theme_support('title-tag');
    
    // Add post thumbnails
    add_theme_support('post-thumbnails');
    
    // Add custom logo
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // WooCommerce support
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary'   => __('Primary Menu', 'lxi-theme'),
        'footer'    => __('Footer Menu', 'lxi-theme'),
    ));
    
    // HTML5 support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
}
add_action('after_setup_theme', 'lxi_theme_setup');

/**
 * Enqueue scripts and styles
 */
function lxi_enqueue_assets() {
    // Google Fonts
    wp_enqueue_style(
        'lxi-google-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&family=Inter:wght@300;400;500&family=Montserrat:wght@300;400;500&display=swap',
        array(),
        null
    );
    
    // Main stylesheet
    wp_enqueue_style(
        'lxi-style',
        get_stylesheet_uri(),
        array(),
        '1.0.0'
    );
    
    // Main JavaScript
    wp_enqueue_script(
        'lxi-main',
        get_template_directory_uri() . '/assets/js/main.js',
        array('jquery'),
        '1.0.0',
        true
    );
    
    // Pass data to JavaScript
    wp_localize_script('lxi-main', 'lxi_data', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('lxi_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'lxi_enqueue_assets');

/**
 * Customize WooCommerce
 */

// Change "Add to Cart" text
function lxi_add_to_cart_text($text) {
    return __('ADD TO ARMOR', 'lxi-theme');
}
add_filter('woocommerce_product_single_add_to_cart_text', 'lxi_add_to_cart_text');
add_filter('woocommerce_product_add_to_cart_text', 'lxi_add_to_cart_text');

// Change "Proceed to Checkout" text
function lxi_checkout_button_text($text) {
    return __('PROCEED TO ARMOR', 'lxi-theme');
}
add_filter('woocommerce_order_button_text', 'lxi_checkout_button_text');

// Change "Place Order" text
function lxi_place_order_text($text) {
    return __('COMPLETE ORDER', 'lxi-theme');
}
add_filter('woocommerce_order_button_text', 'lxi_place_order_text');

// Remove default WooCommerce styles
add_filter('woocommerce_enqueue_styles', '__return_empty_array');

// Change products per page
function lxi_products_per_page($cols) {
    return 12;
}
add_filter('loop_shop_per_page', 'lxi_products_per_page');

// Change product columns
function lxi_loop_columns() {
    return 3;
}
add_filter('loop_shop_columns', 'lxi_loop_columns');

// Remove product link wrapper
remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10);
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);

// Remove add to cart button from loop
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);

// Remove sale badge
remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);

// Remove breadcrumbs
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);

// Remove sidebar
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

// Remove related products
remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);

// Remove additional information tab
function lxi_remove_tabs($tabs) {
    unset($tabs['additional_information']);
    unset($tabs['reviews']);
    return $tabs;
}
add_filter('woocommerce_product_tabs', 'lxi_remove_tabs', 98);

/**
 * Custom product loop with link wrapper
 */
function lxi_product_loop_start() {
    global $product;
    echo '<a href="' . esc_url(get_permalink($product->get_id())) . '" class="product-link">';
}
add_action('woocommerce_before_shop_loop_item', 'lxi_product_loop_start', 10);

function lxi_product_loop_end() {
    echo '</a>';
}
add_action('woocommerce_after_shop_loop_item', 'lxi_product_loop_end', 5);

/**
 * Add product category tag above image
 */
function lxi_product_category_tag() {
    global $product;
    $categories = get_the_terms($product->get_id(), 'product_cat');
    if ($categories && !is_wp_error($categories)) {
        $cat_names = array();
        foreach ($categories as $cat) {
            $cat_names[] = $cat->name;
        }
        echo '<div class="product-tag"><span class="micro-label">' . esc_html(strtoupper(implode(' · ', $cat_names))) . ' · FOUNDERS</span></div>';
    }
}
add_action('woocommerce_before_shop_loop_item_title', 'lxi_product_category_tag', 5);

/**
 * Widget areas
 */
function lxi_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Column 1', 'lxi-theme'),
        'id'            => 'footer-1',
        'description'   => __('Footer widget area 1', 'lxi-theme'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-title">',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 2', 'lxi-theme'),
        'id'            => 'footer-2',
        'description'   => __('Footer widget area 2', 'lxi-theme'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-title">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'lxi_widgets_init');

/**
 * Newsletter subscription (AJAX handler)
 */
function lxi_newsletter_subscribe() {
    check_ajax_referer('lxi_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Invalid email address'));
    }
    
    // Store in options or custom table
    $subscribers = get_option('lxi_newsletter_subscribers', array());
    
    if (in_array($email, $subscribers)) {
        wp_send_json_error(array('message' => 'Ya eres parte de la comunidad.'));
    }
    
    $subscribers[] = $email;
    update_option('lxi_newsletter_subscribers', $subscribers);
    
    wp_send_json_success(array('message' => 'Bienvenido a la arena.'));
}
add_action('wp_ajax_lxi_newsletter', 'lxi_newsletter_subscribe');
add_action('wp_ajax_nopriv_lxi_newsletter', 'lxi_newsletter_subscribe');

/**
 * Add theme options page
 */
function lxi_add_admin_menu() {
    add_menu_page(
        'LXI Settings',
        'LXI Theme',
        'manage_options',
        'lxi-settings',
        'lxi_settings_page',
        'dashicons-store',
        60
    );
}
add_action('admin_menu', 'lxi_add_admin_menu');

function lxi_settings_page() {
    ?>
    <div class="wrap">
        <h1>LXI Theme Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('lxi_options');
            do_settings_sections('lxi-settings');
            submit_button();
            ?>
        </form>
        
        <hr>
        <h2>Newsletter Subscribers</h2>
        <?php
        $subscribers = get_option('lxi_newsletter_subscribers', array());
        if (!empty($subscribers)) {
            echo '<table class="widefat">';
            echo '<thead><tr><th>Email</th></tr></thead>';
            echo '<tbody>';
            foreach ($subscribers as $email) {
                echo '<tr><td>' . esc_html($email) . '</td></tr>';
            }
            echo '</tbody></table>';
            echo '<p>Total: ' . count($subscribers) . ' subscribers</p>';
        } else {
            echo '<p>No subscribers yet.</p>';
        }
        ?>
    </div>
    <?php
}

function lxi_settings_init() {
    register_setting('lxi_options', 'lxi_hero_image');
    register_setting('lxi_options', 'lxi_hero_title');
    register_setting('lxi_options', 'lxi_hero_subtitle');
    
    add_settings_section(
        'lxi_hero_section',
        'Hero Section',
        null,
        'lxi-settings'
    );
    
    add_settings_field(
        'lxi_hero_image',
        'Hero Background Image URL',
        'lxi_hero_image_render',
        'lxi-settings',
        'lxi_hero_section'
    );
    
    add_settings_field(
        'lxi_hero_title',
        'Hero Title',
        'lxi_hero_title_render',
        'lxi-settings',
        'lxi_hero_section'
    );
    
    add_settings_field(
        'lxi_hero_subtitle',
        'Hero Subtitle',
        'lxi_hero_subtitle_render',
        'lxi-settings',
        'lxi_hero_section'
    );
}
add_action('admin_init', 'lxi_settings_init');

function lxi_hero_image_render() {
    $value = get_option('lxi_hero_image', 'https://images.unsplash.com/photo-1648314789571-4003c96b5b09?w=1920&q=80');
    echo '<input type="text" name="lxi_hero_image" value="' . esc_attr($value) . '" class="regular-text">';
}

function lxi_hero_title_render() {
    $value = get_option('lxi_hero_title', 'LA ARMADURA DEL GLADIADOR MODERNO');
    echo '<input type="text" name="lxi_hero_title" value="' . esc_attr($value) . '" class="regular-text">';
}

function lxi_hero_subtitle_render() {
    $value = get_option('lxi_hero_subtitle', 'Para quienes eligieron enfrentar su arena.');
    echo '<input type="text" name="lxi_hero_subtitle" value="' . esc_attr($value) . '" class="regular-text">';
}

/**
 * Printful Integration Notice
 */
function lxi_printful_admin_notice() {
    if (!class_exists('Printful_Integration')) {
        ?>
        <div class="notice notice-info is-dismissible">
            <p><strong>LXI Theme:</strong> For Print-on-Demand functionality, install the <a href="https://wordpress.org/plugins/printful-shipping-for-woocommerce/" target="_blank">Printful Integration for WooCommerce</a> plugin.</p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'lxi_printful_admin_notice');

/**
 * Mini cart fragment for AJAX update
 */
function lxi_cart_count_fragment($fragments) {
    ob_start();
    ?>
    <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
    <?php
    $fragments['.cart-count'] = ob_get_clean();
    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'lxi_cart_count_fragment');

/**
 * Free shipping progress
 */
function lxi_free_shipping_amount() {
    $min_amount = 150; // Free shipping threshold
    $current = WC()->cart->get_subtotal();
    $remaining = $min_amount - $current;
    
    return array(
        'threshold' => $min_amount,
        'current'   => $current,
        'remaining' => max(0, $remaining),
        'progress'  => min(100, ($current / $min_amount) * 100),
    );
}
