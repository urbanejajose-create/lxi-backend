<?php
/**
 * Front Page Template
 * 
 * @package LXI_Theme
 */

get_header();

// Get theme options
$hero_image = get_option('lxi_hero_image', 'https://images.unsplash.com/photo-1648314789571-4003c96b5b09?w=1920&q=80');
$hero_title = get_option('lxi_hero_title', 'LA ARMADURA DEL GLADIADOR MODERNO');
$hero_subtitle = get_option('lxi_hero_subtitle', 'Para quienes eligieron enfrentar su arena.');
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-bg" style="background-image: url('<?php echo esc_url($hero_image); ?>');"></div>
    <div class="hero-overlay"></div>
    
    <div class="hero-content">
        <span class="micro-label fade-in-up">FOUNDERS EDITION — DROP 01</span>
        
        <h1 class="hero-title fade-in-up" style="animation-delay: 0.2s;">
            <?php echo esc_html($hero_title); ?>
        </h1>
        
        <p class="hero-subtitle fade-in-up" style="animation-delay: 0.3s;">
            <?php echo esc_html($hero_subtitle); ?>
        </p>
        
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="btn btn-gold-outline mt-10 fade-in-up" style="animation-delay: 0.4s;">
            ENTER DROP 01
        </a>
    </div>
    
    <button class="scroll-indicator" onclick="document.getElementById('brand-statement').scrollIntoView({behavior: 'smooth'})" aria-label="Scroll down">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
        </svg>
    </button>
</section>

<!-- Brand Statement Section -->
<section id="brand-statement" class="brand-statement">
    <div class="container">
        <blockquote class="quote-text">
            "No vendemos ropa. Vendemos la armadura que te recuerda quién decidiste ser."
        </blockquote>
        
        <div class="brand-pillars">
            <div class="brand-pillar">
                <span class="pillar-numeral">I</span>
                <h3 class="pillar-title">DISCIPLINA</h3>
                <p class="pillar-desc">La consistencia silenciosa que construye identidad.</p>
            </div>
            <div class="brand-pillar">
                <span class="pillar-numeral">II</span>
                <h3 class="pillar-title">PRESENCIA</h3>
                <p class="pillar-desc">La autoridad que no necesita anunciarse.</p>
            </div>
            <div class="brand-pillar">
                <span class="pillar-numeral">III</span>
                <h3 class="pillar-title">LEGADO</h3>
                <p class="pillar-desc">Lo que permanece cuando el miedo desaparece.</p>
            </div>
        </div>
    </div>
</section>

<!-- Collection Preview -->
<section class="py-24">
    <div class="container">
        <div class="section-header mb-8">
            <span class="micro-label">DROP 01 — FOUNDERS EDITION</span>
            <h2 class="section-title mt-4">La Colección</h2>
        </div>
        
        <?php
        // Get featured products
        $args = array(
            'post_type'      => 'product',
            'posts_per_page' => 3,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );
        $products = new WP_Query($args);
        
        if ($products->have_posts()) :
            woocommerce_product_loop_start();
            while ($products->have_posts()) : $products->the_post();
                wc_get_template_part('content', 'product');
            endwhile;
            woocommerce_product_loop_end();
        endif;
        wp_reset_postdata();
        ?>
        
        <div class="text-center mt-12">
            <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="view-more">
                VIEW FULL COLLECTION
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    </div>
</section>

<!-- Brand Story Teaser -->
<section class="brand-statement">
    <div class="container">
        <div style="display: grid; grid-template-columns: 1fr; gap: 48px; align-items: center;">
            <?php if (has_post_thumbnail()) : ?>
            <div>
                <img src="https://images.unsplash.com/photo-1705513010372-b3ba14ef4530?w=1200&q=80" alt="LXI Philosophy" style="width: 100%; aspect-ratio: 4/3; object-fit: cover;">
            </div>
            <?php endif; ?>
            <div>
                <span class="micro-label">NACIÓ DE UNA BATALLA</span>
                <h2 class="section-title mt-4 mb-8" style="font-size: 32px;">
                    Cada pieza LXI es un recordatorio de que la batalla más difícil ya comenzó.
                </h2>
                <p style="color: var(--lxi-secondary-text); font-size: 14px; line-height: 1.8; margin-bottom: 32px;">
                    LXI nació de un libro. De una batalla personal escrita para millones que pelean la misma guerra silenciosa: el síndrome del impostor. "Luchando con el Impostor" no es una metáfora. Es un método. Y LXI es su armadura.
                </p>
                <a href="<?php echo esc_url(home_url('/philosophy/')); ?>" class="view-more">
                    READ THE PHILOSOPHY
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Drop Banner -->
<section style="padding: 64px 0; border-top: 1px solid var(--lxi-accent-gold); border-bottom: 1px solid var(--lxi-accent-gold); text-align: center;">
    <div class="container">
        <span class="micro-label">FOUNDERS EDITION — AVAILABLE FOR LIMITED TIME</span>
        <p style="color: var(--lxi-secondary-text); font-size: 14px; letter-spacing: 0.1em; margin-top: 16px;">MMXXVI · EACH PIECE MADE TO ORDER</p>
    </div>
</section>

<?php get_footer(); ?>
