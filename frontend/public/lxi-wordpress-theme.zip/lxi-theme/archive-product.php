<?php
/**
 * WooCommerce Archive (Shop) Template
 * 
 * @package LXI_Theme
 */

get_header();
?>

<div class="container" style="padding-top: 128px; padding-bottom: 96px;">
    <!-- Page Header -->
    <div class="page-header" style="padding-top: 0; text-align: left; margin-bottom: 48px;">
        <h1 class="page-title">DROP 01</h1>
        <p class="micro-label" style="margin-top: 16px;">
            FOUNDERS EDITION — <?php echo wc_get_loop_prop('total'); ?> PIECES
        </p>
    </div>
    
    <!-- Category Filter -->
    <div style="display: flex; flex-wrap: wrap; gap: 24px; margin-bottom: 48px; padding-bottom: 24px; border-bottom: 1px solid var(--lxi-border);">
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" 
           class="filter-link <?php echo !is_product_category() ? 'active' : ''; ?>"
           style="color: <?php echo !is_product_category() ? 'var(--lxi-accent-gold)' : 'var(--lxi-secondary-text)'; ?>; font-size: 11px; letter-spacing: 0.2em; text-decoration: none;">
            ALL
        </a>
        <?php
        $categories = get_terms(array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => true,
        ));
        
        foreach ($categories as $cat) :
            $is_active = is_product_category($cat->slug);
        ?>
        <a href="<?php echo esc_url(get_term_link($cat)); ?>" 
           class="filter-link <?php echo $is_active ? 'active' : ''; ?>"
           style="color: <?php echo $is_active ? 'var(--lxi-accent-gold)' : 'var(--lxi-secondary-text)'; ?>; font-size: 11px; letter-spacing: 0.2em; text-decoration: none;">
            <?php echo esc_html(strtoupper($cat->name)); ?>
        </a>
        <?php endforeach; ?>
    </div>
    
    <!-- Products Grid -->
    <?php
    if (woocommerce_product_loop()) {
        woocommerce_product_loop_start();
        
        if (wc_get_loop_prop('total')) {
            while (have_posts()) {
                the_post();
                wc_get_template_part('content', 'product');
            }
        }
        
        woocommerce_product_loop_end();
    } else {
        do_action('woocommerce_no_products_found');
    }
    ?>
    
    <!-- Drop Banner -->
    <div style="margin-top: 96px; padding: 48px 0; border-top: 1px solid var(--lxi-accent-gold); border-bottom: 1px solid var(--lxi-accent-gold); text-align: center;">
        <span class="micro-label">FOUNDERS EDITION — AVAILABLE FOR LIMITED TIME</span>
        <p style="color: var(--lxi-secondary-text); font-size: 14px; letter-spacing: 0.1em; margin-top: 16px;">
            PRODUCED ON DEMAND · SHIPS VIA PRINTFUL
        </p>
    </div>
</div>

<?php get_footer(); ?>
