<?php
/**
 * Main index template
 * 
 * @package LXI_Theme
 */

get_header();
?>

<div class="container py-24" style="padding-top: 160px;">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            the_content();
        endwhile;
    endif;
    ?>
</div>

<?php get_footer(); ?>
