<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Header -->
<header class="site-header" id="site-header">
    <div class="container">
        <div class="header-inner">
            <!-- Logo -->
            <div class="site-logo">
                <a href="<?php echo esc_url(home_url('/')); ?>">LXI</a>
            </div>
            
            <!-- Main Navigation -->
            <nav class="main-navigation">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => 'lxi_fallback_menu',
                ));
                ?>
            </nav>
            
            <!-- Header Actions -->
            <div class="header-actions">
                <!-- Cart -->
                <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="cart-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                    <?php if (WC()->cart->get_cart_contents_count() > 0) : ?>
                    <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                    <?php endif; ?>
                </a>
                
                <!-- Mobile Menu Toggle -->
                <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="Open menu">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="12" x2="21" y2="12"></line>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <line x1="3" y1="18" x2="21" y2="18"></line>
                    </svg>
                </button>
            </div>
        </div>
    </div>
</header>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobile-menu">
    <button class="mobile-menu-close" id="mobile-menu-close" aria-label="Close menu">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
    </button>
    <?php
    wp_nav_menu(array(
        'theme_location' => 'primary',
        'container'      => false,
        'fallback_cb'    => 'lxi_fallback_menu',
    ));
    ?>
    <div style="position: absolute; bottom: 48px; text-align: center;">
        <p class="micro-label">FOUNDERS EDITION</p>
        <p style="color: var(--lxi-secondary-text); font-size: 12px; margin-top: 8px; letter-spacing: 0.1em;">MMXXVI</p>
    </div>
</div>

<?php
// Fallback menu if no menu is set
function lxi_fallback_menu() {
    ?>
    <ul>
        <li><a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>">SHOP</a></li>
        <li><a href="<?php echo esc_url(home_url('/philosophy/')); ?>">PHILOSOPHY</a></li>
        <li><a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>">DROP 01</a></li>
    </ul>
    <?php
}
?>

<main class="site-content">
