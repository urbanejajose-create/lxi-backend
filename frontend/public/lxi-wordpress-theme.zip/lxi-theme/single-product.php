<?php
/**
 * Single Product Template
 * 
 * @package LXI_Theme
 */

get_header();

while (have_posts()) : the_post();
    global $product;
?>

<div class="container" style="padding-top: 96px; padding-bottom: 96px;">
    <!-- Breadcrumb -->
    <nav style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--lxi-secondary-text); margin-bottom: 32px;">
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" style="color: var(--lxi-secondary-text); text-decoration: none;">SHOP</a>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" style="color: var(--lxi-secondary-text); text-decoration: none;">DROP 01</a>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"></polyline>
        </svg>
        <span style="color: var(--lxi-primary-text);"><?php the_title(); ?></span>
    </nav>
    
    <div style="display: grid; grid-template-columns: 1fr; gap: 32px;">
        <?php /* On larger screens, this becomes 2 columns via CSS */ ?>
        
        <!-- Product Gallery -->
        <div class="product-gallery">
            <div style="aspect-ratio: 1; background: var(--lxi-secondary-bg); overflow: hidden; margin-bottom: 16px;">
                <?php
                $image_id = $product->get_image_id();
                if ($image_id) {
                    echo wp_get_attachment_image($image_id, 'large', false, array('style' => 'width: 100%; height: 100%; object-fit: cover;'));
                } else {
                    echo wc_placeholder_img();
                }
                ?>
            </div>
            
            <?php
            $gallery_ids = $product->get_gallery_image_ids();
            if (!empty($gallery_ids)) :
            ?>
            <div style="display: flex; gap: 12px;">
                <?php foreach ($gallery_ids as $gallery_id) : ?>
                <button style="width: 80px; height: 80px; border: 1px solid var(--lxi-border); background: none; cursor: pointer; overflow: hidden; padding: 0;">
                    <?php echo wp_get_attachment_image($gallery_id, 'thumbnail', false, array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                </button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Product Info -->
        <div class="product-info">
            <span class="micro-label">FOUNDERS EDITION</span>
            
            <h1 style="font-size: 32px; color: var(--lxi-primary-text); margin-top: 16px; margin-bottom: 16px;">
                <?php the_title(); ?>
            </h1>
            
            <p style="color: var(--lxi-accent-gold); font-size: 24px; margin-bottom: 24px;">
                <?php echo $product->get_price_html(); ?>
            </p>
            
            <div style="color: var(--lxi-secondary-text); font-size: 14px; line-height: 1.8; margin-bottom: 32px;">
                <?php echo wpautop($product->get_short_description()); ?>
            </div>
            
            <?php woocommerce_template_single_add_to_cart(); ?>
            
            <p style="color: var(--lxi-secondary-text); font-size: 12px; text-align: center; margin-top: 16px; margin-bottom: 32px;">
                Free shipping on orders over $150 · Ships via Printful
            </p>
            
            <!-- Gold Divider -->
            <div style="height: 1px; background: var(--lxi-accent-gold); margin-bottom: 32px;"></div>
            
            <!-- Product Details Accordion -->
            <?php
            $tabs = array(
                'material' => array('MATERIAL & CRAFT', $product->get_attribute('material') ?: 'Premium quality materials with embroidered LXI crest.'),
                'sizing' => array('SIZING', $product->get_attribute('sizing') ?: 'Cut for presence. Slightly oversized by design.'),
                'shipping' => array('SHIPPING & RETURNS', 'Produced on demand. Ships in 3-7 business days. Final sale — each piece made for you.'),
            );
            
            foreach ($tabs as $id => $tab) :
            ?>
            <div class="accordion-item" style="border-bottom: 1px solid var(--lxi-border);">
                <button class="accordion-trigger" onclick="this.parentElement.classList.toggle('open')" style="width: 100%; display: flex; justify-content: space-between; align-items: center; padding: 16px 0; background: none; border: none; color: var(--lxi-primary-text); font-family: var(--lxi-font-accent); font-size: 11px; letter-spacing: 0.2em; cursor: pointer;">
                    <?php echo $tab[0]; ?>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="transition: transform 0.3s ease;">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </button>
                <div class="accordion-content" style="display: none; color: var(--lxi-secondary-text); font-size: 14px; line-height: 1.8; padding-bottom: 16px;">
                    <?php echo $tab[1]; ?>
                </div>
            </div>
            <?php endforeach; ?>
            
            <!-- Brand Badge -->
            <div style="display: flex; align-items: center; gap: 12px; margin-top: 32px; color: var(--lxi-secondary-text); font-size: 12px;">
                <span style="color: var(--lxi-accent-gold); font-family: var(--lxi-font-heading); font-size: 18px;">I</span>
                <span>Part of Drop 01 — Founders Edition MMXXVI</span>
            </div>
        </div>
    </div>
</div>

<style>
.accordion-item.open .accordion-trigger svg {
    transform: rotate(180deg);
}
.accordion-item.open .accordion-content {
    display: block !important;
}
@media (min-width: 1024px) {
    .container > div:last-child {
        display: grid;
        grid-template-columns: 3fr 2fr;
        gap: 64px;
    }
    .product-info {
        position: sticky;
        top: 128px;
        align-self: start;
    }
}
</style>

<?php
endwhile;

get_footer();
?>
