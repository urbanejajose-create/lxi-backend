</main><!-- .site-content -->

<!-- Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- Brand Column -->
            <div>
                <div class="footer-logo">
                    <a href="<?php echo esc_url(home_url('/')); ?>">LXI</a>
                </div>
                <p class="footer-desc">
                    Vestir la transformación de quienes eligieron enfrentar su arena.
                </p>
                <div class="footer-socials">
                    <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                        </svg>
                    </a>
                    <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" aria-label="TikTok">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/>
                        </svg>
                    </a>
                </div>
            </div>
            
            <!-- Navigation Columns -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 32px;">
                <div>
                    <h4 class="footer-title">SHOP</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>">DROP 01</a></li>
                        <?php
                        $categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => true));
                        foreach ($categories as $cat) {
                            echo '<li><a href="' . esc_url(get_term_link($cat)) . '">' . esc_html(strtoupper($cat->name)) . '</a></li>';
                        }
                        ?>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-title">BRAND</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo esc_url(home_url('/philosophy/')); ?>">PHILOSOPHY</a></li>
                        <li><a href="<?php echo esc_url(home_url('/philosophy/')); ?>">THE BOOK</a></li>
                    </ul>
                </div>
            </div>
            
            <!-- Newsletter -->
            <div class="footer-newsletter">
                <h4 class="footer-title">ENTER THE ARENA</h4>
                <p>Sé el primero en conocer los nuevos drops y la filosofía LXI.</p>
                <form id="newsletter-form">
                    <input type="email" name="email" placeholder="Tu email" required>
                    <button type="submit" class="btn btn-gold-outline">ENTER THE ARENA</button>
                </form>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> LXI. All rights reserved.</p>
            <p style="letter-spacing: 0.2em;">FOUNDERS EDITION MMXXVI</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
