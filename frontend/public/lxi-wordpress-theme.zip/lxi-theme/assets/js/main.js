/**
 * LXI Theme JavaScript
 */

(function($) {
    'use strict';
    
    // Navbar scroll effect
    function initNavbar() {
        const header = document.getElementById('site-header');
        if (!header) return;
        
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
    
    // Mobile menu
    function initMobileMenu() {
        const toggle = document.getElementById('mobile-menu-toggle');
        const close = document.getElementById('mobile-menu-close');
        const menu = document.getElementById('mobile-menu');
        
        if (toggle && menu) {
            toggle.addEventListener('click', function() {
                menu.classList.add('active');
                document.body.style.overflow = 'hidden';
            });
        }
        
        if (close && menu) {
            close.addEventListener('click', function() {
                menu.classList.remove('active');
                document.body.style.overflow = '';
            });
        }
        
        // Close on link click
        const links = menu ? menu.querySelectorAll('a') : [];
        links.forEach(function(link) {
            link.addEventListener('click', function() {
                menu.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }
    
    // Newsletter form
    function initNewsletter() {
        const form = document.getElementById('newsletter-form');
        if (!form) return;
        
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = form.querySelector('input[name="email"]').value;
            const button = form.querySelector('button');
            
            button.disabled = true;
            button.textContent = 'ENTRANDO...';
            
            $.ajax({
                url: lxi_data.ajax_url,
                type: 'POST',
                data: {
                    action: 'lxi_newsletter',
                    nonce: lxi_data.nonce,
                    email: email
                },
                success: function(response) {
                    if (response.success) {
                        showToast('Bienvenido a la arena.', 'success');
                        form.querySelector('input[name="email"]').value = '';
                    } else {
                        showToast(response.data.message || 'Ya eres parte de la comunidad.', 'info');
                    }
                },
                error: function() {
                    showToast('Error al suscribirte. Intenta de nuevo.', 'error');
                },
                complete: function() {
                    button.disabled = false;
                    button.textContent = 'ENTER THE ARENA';
                }
            });
        });
    }
    
    // Toast notifications
    function showToast(message, type) {
        // Remove existing toast
        const existing = document.querySelector('.lxi-toast');
        if (existing) existing.remove();
        
        const toast = document.createElement('div');
        toast.className = 'lxi-toast ' + type;
        toast.innerHTML = '<span>' + message + '</span>';
        toast.style.cssText = 'position: fixed; top: 24px; left: 50%; transform: translateX(-50%); background: var(--lxi-secondary-bg); border: 1px solid var(--lxi-border); color: var(--lxi-primary-text); padding: 16px 24px; font-size: 14px; z-index: 9999; opacity: 0; transition: opacity 0.3s ease;';
        
        if (type === 'success') {
            toast.style.borderColor = 'var(--lxi-accent-gold)';
        }
        
        document.body.appendChild(toast);
        
        setTimeout(function() {
            toast.style.opacity = '1';
        }, 10);
        
        setTimeout(function() {
            toast.style.opacity = '0';
            setTimeout(function() {
                toast.remove();
            }, 300);
        }, 3000);
    }
    
    // Product image gallery
    function initProductGallery() {
        const thumbnails = document.querySelectorAll('.woocommerce-product-gallery__image');
        const mainImage = document.querySelector('.woocommerce-product-gallery__wrapper img');
        
        thumbnails.forEach(function(thumb) {
            thumb.addEventListener('click', function(e) {
                e.preventDefault();
                const newSrc = thumb.querySelector('a').getAttribute('href');
                if (mainImage && newSrc) {
                    mainImage.src = newSrc;
                }
            });
        });
    }
    
    // Size selector styling
    function initSizeSelector() {
        const selects = document.querySelectorAll('.variations select');
        selects.forEach(function(select) {
            select.addEventListener('change', function() {
                // Add visual feedback
                this.style.borderColor = 'var(--lxi-accent-gold)';
            });
        });
    }
    
    // Initialize all
    document.addEventListener('DOMContentLoaded', function() {
        initNavbar();
        initMobileMenu();
        initNewsletter();
        initProductGallery();
        initSizeSelector();
    });
    
})(jQuery);
