<?php
/**
 * Philosophy Page Template
 * Template Name: Philosophy
 * 
 * @package LXI_Theme
 */

get_header();
?>

<!-- Hero -->
<section style="position: relative; height: 60vh; min-height: 400px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
    <div style="position: absolute; inset: 0; background: url('https://images.unsplash.com/photo-1648314789571-4003c96b5b09?w=1920&q=80') center/cover;"></div>
    <div style="position: absolute; inset: 0; background: rgba(10, 14, 23, 0.7);"></div>
    <div style="position: relative; z-index: 10; text-align: center;">
        <span class="micro-label">LA FILOSOFÍA LXI</span>
    </div>
</section>

<!-- Manifesto -->
<section class="py-32">
    <div class="container" style="max-width: 680px;">
        <!-- Opening Quote -->
        <blockquote class="quote-text mb-8" style="margin-bottom: 80px;">
            "El gladiador no entra a la arena porque no tiene miedo. Entra porque decidió que la batalla vale más que el miedo."
        </blockquote>
        
        <!-- Act I -->
        <div style="margin-bottom: 80px;">
            <span class="micro-label">ACT I</span>
            <h2 class="section-title mt-4 mb-8">EL ORIGEN</h2>
            <div style="color: var(--lxi-secondary-text); font-size: 16px; line-height: 1.9;">
                <p style="margin-bottom: 24px;">LXI nació de un libro. De una batalla personal escrita para millones que pelean la misma guerra silenciosa: el síndrome del impostor.</p>
                <p>"Luchando con el Impostor" no es una metáfora. Es un método. Y LXI es su armadura.</p>
            </div>
        </div>
        
        <!-- Act II -->
        <div style="margin-bottom: 80px;">
            <span class="micro-label">ACT II</span>
            <h2 class="section-title mt-4 mb-8">LA TRANSFORMACIÓN</h2>
            <div style="color: var(--lxi-secondary-text); font-size: 16px; line-height: 1.9;">
                <p style="margin-bottom: 24px;">Existen dos tipos de personas en cualquier arena: los que esperan sentirse listos para entrar, y los que entran sabiendo que el miedo nunca desaparece.</p>
                <p>LXI viste a los segundos.</p>
            </div>
        </div>
        
        <!-- Act III -->
        <div style="margin-bottom: 80px;">
            <span class="micro-label">ACT III</span>
            <h2 class="section-title mt-4 mb-8">EL ESTÁNDAR</h2>
            <div style="color: var(--lxi-secondary-text); font-size: 16px; line-height: 1.9;">
                <p style="margin-bottom: 24px;">Cada pieza LXI es diseñada bajo un solo criterio: ¿Tiene la presencia silenciosa de quien ya ganó su primera batalla?</p>
                <p>Si la respuesta es no, no existe.</p>
            </div>
        </div>
    </div>
</section>

<!-- Brand Values -->
<section class="brand-statement">
    <div class="container" style="max-width: 900px;">
        <div class="text-center mb-8" style="margin-bottom: 64px;">
            <span class="micro-label">LOS VALORES</span>
            <h2 class="section-title mt-4">Cinco Pilares</h2>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 48px;">
            <?php
            $values = array(
                array('I', 'ARENA', 'El espacio donde decides aparecer. No el escenario que te espera, sino el que construyes con cada decisión.'),
                array('II', 'DISCIPLINA', 'La consistencia silenciosa que construye identidad. No lo que haces cuando te observan, sino lo que repites cuando nadie mira.'),
                array('III', 'PRESENCIA', 'La autoridad que no necesita anunciarse. El poder de ocupar un espacio sin pedirlo ni disculparte.'),
                array('IV', 'TRANSFORMACIÓN', 'El proceso, no el destino. El arte de convertirte en quien decidiste ser, una batalla a la vez.'),
                array('V', 'LEGADO', 'Lo que permanece cuando el miedo desaparece. La huella que dejas en los que te observan pelear.'),
            );
            
            foreach ($values as $value) :
            ?>
            <div style="display: flex; gap: 32px; align-items: flex-start; border-left: 1px solid var(--lxi-border); padding-left: 32px;">
                <span style="color: var(--lxi-accent-gold); font-family: var(--lxi-font-heading); font-size: 40px; flex-shrink: 0; width: 48px;"><?php echo $value[0]; ?></span>
                <div>
                    <h3 style="color: var(--lxi-primary-text); font-size: 16px; letter-spacing: 0.2em; font-family: var(--lxi-font-body); font-weight: 500; margin-bottom: 12px;"><?php echo $value[1]; ?></h3>
                    <p style="color: var(--lxi-secondary-text); font-size: 14px; line-height: 1.8;"><?php echo $value[2]; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<section class="py-32">
    <div class="container" style="max-width: 900px;">
        <div style="border: 1px solid var(--lxi-accent-gold); padding: 48px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 48px;">
                <div>
                    <span class="micro-label">MISIÓN</span>
                    <p style="font-family: var(--lxi-font-heading); font-size: 24px; color: var(--lxi-primary-text); line-height: 1.4; margin-top: 16px;">
                        Vestir la transformación de quienes eligieron enfrentar su arena.
                    </p>
                </div>
                <div>
                    <span class="micro-label">VISIÓN</span>
                    <p style="font-family: var(--lxi-font-heading); font-size: 24px; color: var(--lxi-primary-text); line-height: 1.4; margin-top: 16px;">
                        Ser la marca que los gladiadores modernos reconocen como suya.
                    </p>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-12">
            <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="view-more">
                EXPLORE THE COLLECTION
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
