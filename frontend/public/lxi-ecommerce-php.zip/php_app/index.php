<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/models.php';

$productModel = new Product();
$products = $productModel->getAll();
$featuredProducts = array_slice($products, 0, 3);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LXI - La Armadura del Gladiador Moderno</title>
    <meta name="description" content="Vestir la transformación de quienes eligieron enfrentar su arena.">
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar" data-testid="main-navbar">
        <div class="container">
            <div class="navbar-inner">
                <a href="/php_app/" class="logo" data-testid="logo-link">LXI</a>
                
                <ul class="nav-links">
                    <li><a href="/php_app/shop.php" class="nav-link">SHOP</a></li>
                    <li><a href="/php_app/philosophy.php" class="nav-link">PHILOSOPHY</a></li>
                    <li><a href="/php_app/shop.php" class="nav-link">DROP 01</a></li>
                </ul>
                
                <div class="nav-actions">
                    <button class="cart-btn" data-testid="cart-button" aria-label="Open cart">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" data-testid="cart-count" style="display: none;">0</span>
                    </button>
                    
                    <button class="mobile-menu-btn" aria-label="Open menu">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="3" y1="12" x2="21" y2="12"></line>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <line x1="3" y1="18" x2="21" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Mobile Menu -->
    <div class="mobile-menu" data-testid="mobile-menu">
        <button class="mobile-menu-close" aria-label="Close menu">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
        <ul class="mobile-menu-links">
            <li><a href="/php_app/shop.php" class="mobile-menu-link">SHOP</a></li>
            <li><a href="/php_app/philosophy.php" class="mobile-menu-link">PHILOSOPHY</a></li>
            <li><a href="/php_app/shop.php" class="mobile-menu-link">DROP 01</a></li>
        </ul>
        <div style="position: absolute; bottom: 48px; text-align: center;">
            <p class="micro-label">FOUNDERS EDITION</p>
            <p style="color: var(--lxi-secondary-text); font-size: 12px; margin-top: 8px; letter-spacing: 0.1em;">MMXXVI</p>
        </div>
    </div>
    
    <!-- Hero Section -->
    <section class="hero" data-testid="hero-section">
        <div class="hero-bg" style="background-image: url('https://images.unsplash.com/photo-1648314789571-4003c96b5b09?w=1920&q=80');"></div>
        <div class="hero-overlay"></div>
        
        <div class="hero-content">
            <span class="micro-label fade-in-up">FOUNDERS EDITION — DROP 01</span>
            
            <h1 class="hero-title fade-in-up" data-testid="hero-headline" style="animation-delay: 0.2s;">
                LA ARMADURA DEL<br>GLADIADOR MODERNO
            </h1>
            
            <p class="hero-subtitle fade-in-up" style="animation-delay: 0.3s;">
                Para quienes eligieron enfrentar su arena.
            </p>
            
            <a href="/php_app/shop.php" class="btn btn-gold-outline mt-10 fade-in-up" data-testid="hero-cta" style="animation-delay: 0.4s;">
                ENTER DROP 01
            </a>
        </div>
        
        <button class="scroll-indicator" onclick="scrollToContent()" aria-label="Scroll down">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
        </button>
    </section>
    
    <!-- Brand Statement Section -->
    <section id="brand-statement" class="brand-statement" data-testid="brand-statement-section">
        <div class="container">
            <blockquote class="quote-text">
                "No vendemos ropa. Vendemos la armadura que te recuerda quién decidiste ser."
            </blockquote>
            
            <div class="brand-pillars">
                <div class="brand-pillar">
                    <span class="pillar-numeral">I</span>
                    <h3 class="pillar-title">DISCIPLINA</h3>
                    <p class="pillar-desc">La consistencia silenciosa que construye identidad.</p>
                </div>
                <div class="brand-pillar">
                    <span class="pillar-numeral">II</span>
                    <h3 class="pillar-title">PRESENCIA</h3>
                    <p class="pillar-desc">La autoridad que no necesita anunciarse.</p>
                </div>
                <div class="brand-pillar">
                    <span class="pillar-numeral">III</span>
                    <h3 class="pillar-title">LEGADO</h3>
                    <p class="pillar-desc">Lo que permanece cuando el miedo desaparece.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Collection Preview -->
    <section class="py-24" data-testid="collection-section">
        <div class="container">
            <div class="section-header">
                <span class="micro-label">DROP 01 — FOUNDERS EDITION</span>
                <h2 class="section-title">La Colección</h2>
            </div>
            
            <div class="product-grid">
                <?php foreach ($featuredProducts as $product): ?>
                <a href="/php_app/product.php?slug=<?= htmlspecialchars($product['slug']) ?>" 
                   class="product-card" 
                   data-testid="product-card-<?= htmlspecialchars($product['slug']) ?>">
                    <div class="product-card-image">
                        <img src="<?= htmlspecialchars($product['image1']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                        <div class="product-card-tag">
                            <span class="micro-label"><?= htmlspecialchars($product['tag']) ?></span>
                        </div>
                        <div class="product-card-overlay">
                            <span>VIEW PIECE</span>
                        </div>
                    </div>
                    <div class="product-card-info">
                        <h3 class="product-card-name"><?= htmlspecialchars($product['name']) ?></h3>
                        <p class="product-card-price">$<?= number_format($product['price'], 0) ?></p>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-12">
                <a href="/php_app/shop.php" class="view-more" data-testid="view-collection-link">
                    VIEW FULL COLLECTION
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </section>
    
    <!-- Brand Story Teaser -->
    <section class="brand-story" data-testid="brand-story-section">
        <div class="container">
            <div class="brand-story-grid">
                <div class="brand-story-image">
                    <img src="https://images.unsplash.com/photo-1705513010372-b3ba14ef4530?w=1200&q=80" alt="LXI Philosophy">
                </div>
                <div>
                    <span class="micro-label">NACIÓ DE UNA BATALLA</span>
                    <h2 class="brand-story-title">
                        Cada pieza LXI es un recordatorio de que la batalla más difícil ya comenzó.
                    </h2>
                    <p class="brand-story-text">
                        LXI nació de un libro. De una batalla personal escrita para millones que pelean la misma guerra silenciosa: el síndrome del impostor. "Luchando con el Impostor" no es una metáfora. Es un método. Y LXI es su armadura.
                    </p>
                    <a href="/php_app/philosophy.php" class="view-more" data-testid="read-philosophy-link">
                        READ THE PHILOSOPHY
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Drop Banner -->
    <section class="drop-banner" data-testid="drop-banner-section">
        <div class="container">
            <span class="micro-label">FOUNDERS EDITION — AVAILABLE FOR LIMITED TIME</span>
            <p class="drop-banner-text">MMXXVI · EACH PIECE MADE TO ORDER</p>
        </div>
    </section>
    
    <?php include __DIR__ . '/includes/footer.php'; ?>
    <?php include __DIR__ . '/includes/cart-drawer.php'; ?>
    
    <script src="/php_app/assets/js/main.js"></script>
</body>
</html>
