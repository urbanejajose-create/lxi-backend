<?php
require_once __DIR__ . '/includes/config.php';

$sessionId = isset($_GET['session_id']) ? $_GET['session_id'] : null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orden Confirmada - LXI</title>
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
</head>
<body>
    <main class="checkout-page" data-testid="checkout-success-page">
        <div class="checkout-content">
            <div class="checkout-icon success">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
            </div>
            
            <span class="micro-label">ORDEN CONFIRMADA</span>
            
            <h1 class="checkout-title">Bienvenido a la Arena</h1>
            
            <p class="checkout-text">
                Tu armadura está en camino. Recibirás un email de confirmación con los detalles de envío.
            </p>
            
            <div class="checkout-shipping">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                </svg>
                <span>SHIPS IN 3-7 BUSINESS DAYS</span>
            </div>
            
            <a href="/php_app/shop.php" class="view-more" data-testid="continue-shopping-link">
                CONTINUE SHOPPING
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    </main>
    
    <script src="/php_app/assets/js/main.js"></script>
    <?php if ($sessionId): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            clearCart();
            checkPaymentStatus('<?= htmlspecialchars($sessionId) ?>');
        });
    </script>
    <?php endif; ?>
</body>
</html>
