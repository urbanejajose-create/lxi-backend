<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/models.php';

$slug = isset($_GET['slug']) ? $_GET['slug'] : null;

if (!$slug) {
    header('Location: /php_app/shop.php');
    exit;
}

$productModel = new Product();
$product = $productModel->getBySlug($slug);

if (!$product) {
    header('Location: /php_app/shop.php');
    exit;
}

$sizes = explode(',', $product['sizes']);
$images = array_filter([$product['image1'], $product['image2'], $product['image3']]);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?> - LXI</title>
    <meta name="description" content="<?= htmlspecialchars($product['description']) ?>">
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar scrolled">
        <div class="container">
            <div class="navbar-inner">
                <a href="/php_app/" class="logo">LXI</a>
                <ul class="nav-links">
                    <li><a href="/php_app/shop.php" class="nav-link">SHOP</a></li>
                    <li><a href="/php_app/philosophy.php" class="nav-link">PHILOSOPHY</a></li>
                    <li><a href="/php_app/shop.php" class="nav-link">DROP 01</a></li>
                </ul>
                <div class="nav-actions">
                    <button class="cart-btn" aria-label="Open cart">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" style="display: none;">0</span>
                    </button>
                    <button class="mobile-menu-btn" aria-label="Open menu">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="3" y1="12" x2="21" y2="12"></line>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <line x1="3" y1="18" x2="21" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <button class="mobile-menu-close" aria-label="Close menu">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
        <ul class="mobile-menu-links">
            <li><a href="/php_app/shop.php" class="mobile-menu-link">SHOP</a></li>
            <li><a href="/php_app/philosophy.php" class="mobile-menu-link">PHILOSOPHY</a></li>
            <li><a href="/php_app/shop.php" class="mobile-menu-link">DROP 01</a></li>
        </ul>
    </div>
    
    <main data-testid="product-detail-page" class="product-detail">
        <div class="container">
            <!-- Breadcrumb -->
            <nav class="breadcrumb" data-testid="breadcrumb">
                <a href="/php_app/shop.php">SHOP</a>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
                <a href="/php_app/shop.php">DROP 01</a>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
                <span style="color: var(--lxi-primary-text);"><?= htmlspecialchars($product['name']) ?></span>
            </nav>
            
            <div class="product-detail-grid">
                <!-- Image Gallery -->
                <div class="product-gallery">
                    <div class="product-main-image" data-testid="main-product-image">
                        <img src="<?= htmlspecialchars($images[0]) ?>" alt="<?= htmlspecialchars($product['name']) ?>" id="mainImage">
                    </div>
                    
                    <?php if (count($images) > 1): ?>
                    <div class="product-thumbnails">
                        <?php foreach ($images as $index => $image): ?>
                        <button class="product-thumbnail <?= $index === 0 ? 'active' : '' ?>" data-testid="thumbnail-<?= $index ?>">
                            <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($product['name']) ?> view <?= $index + 1 ?>">
                        </button>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Product Info -->
                <div class="product-info">
                    <span class="micro-label">FOUNDERS EDITION</span>
                    
                    <h1 class="product-name" data-testid="product-title">
                        <?= htmlspecialchars($product['name']) ?>
                    </h1>
                    
                    <p class="product-price" data-testid="product-price">
                        $<?= number_format($product['price'], 0) ?>
                    </p>
                    
                    <p class="product-description">
                        <?= htmlspecialchars($product['description']) ?>
                    </p>
                    
                    <!-- Size Selector -->
                    <div class="size-selector">
                        <div class="size-selector-header">
                            <span class="section-label">SIZE</span>
                            <a href="#" class="size-guide-link" data-testid="size-guide-link">SIZE GUIDE</a>
                        </div>
                        <div class="size-options">
                            <?php foreach ($sizes as $size): ?>
                            <button class="size-btn" data-size="<?= htmlspecialchars(trim($size)) ?>" data-testid="size-<?= htmlspecialchars(trim($size)) ?>">
                                <?= htmlspecialchars(trim($size)) ?>
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Add to Cart -->
                    <button class="btn btn-gold-fill add-to-cart-btn" 
                            data-testid="add-to-cart-button"
                            onclick="handleAddToCart({
                                id: '<?= htmlspecialchars($product['slug']) ?>',
                                name: '<?= htmlspecialchars($product['name']) ?>',
                                price: <?= $product['price'] ?>,
                                image: '<?= htmlspecialchars($images[0]) ?>'
                            })">
                        ADD TO ARMOR
                    </button>
                    
                    <p class="shipping-note">
                        Free shipping on orders over $150 · Ships via Printful
                    </p>
                    
                    <!-- Gold Divider -->
                    <div class="gold-divider"></div>
                    
                    <!-- Product Details Accordion -->
                    <div class="accordion-item" data-testid="accordion-material">
                        <button class="accordion-trigger">
                            MATERIAL & CRAFT
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </button>
                        <div class="accordion-content">
                            <?= htmlspecialchars($product['material_details']) ?>
                        </div>
                    </div>
                    
                    <div class="accordion-item" data-testid="accordion-embroidery">
                        <button class="accordion-trigger">
                            EMBROIDERY DETAIL
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </button>
                        <div class="accordion-content">
                            <?= htmlspecialchars($product['embroidery_details']) ?>
                        </div>
                    </div>
                    
                    <div class="accordion-item" data-testid="accordion-sizing">
                        <button class="accordion-trigger">
                            SIZING
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </button>
                        <div class="accordion-content">
                            <?= htmlspecialchars($product['sizing_details']) ?>
                        </div>
                    </div>
                    
                    <div class="accordion-item" data-testid="accordion-shipping">
                        <button class="accordion-trigger">
                            SHIPPING & RETURNS
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="6 9 12 15 18 9"></polyline>
                            </svg>
                        </button>
                        <div class="accordion-content">
                            <?= htmlspecialchars($product['shipping_details']) ?>
                        </div>
                    </div>
                    
                    <!-- Brand Badge -->
                    <div class="product-badge">
                        <span>I</span>
                        <span>Part of Drop 01 — Founders Edition MMXXVI</span>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <?php include __DIR__ . '/includes/footer.php'; ?>
    <?php include __DIR__ . '/includes/cart-drawer.php'; ?>
    
    <script src="/php_app/assets/js/main.js"></script>
</body>
</html>
