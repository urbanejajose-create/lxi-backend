<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/models.php';

setCorsHeaders();

// Product prices defined server-side (security)
$PRODUCT_PRICES = [
    'heavyweight-tee' => 59.00,
    'snapback-hat' => 45.00,
    'eco-hoodie' => 89.00,
    'cuffed-beanie' => 45.00,
    'long-sleeve-shirt' => 65.00,
];

$orderModel = new Order();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = getJsonInput();
    
    if (empty($data['items']) || !is_array($data['items'])) {
        jsonResponse(['error' => 'Cart is empty'], 400);
    }
    
    $originUrl = isset($data['origin_url']) ? $data['origin_url'] : '';
    
    // Calculate total from server-side prices (security)
    $totalAmount = 0.0;
    $validatedItems = [];
    
    foreach ($data['items'] as $item) {
        $productId = $item['product_id'] ?? '';
        $productPrice = $PRODUCT_PRICES[$productId] ?? null;
        
        if ($productPrice === null) {
            jsonResponse(['error' => 'Invalid product: ' . $productId], 400);
        }
        
        $quantity = intval($item['quantity'] ?? 1);
        $itemTotal = $productPrice * $quantity;
        $totalAmount += $itemTotal;
        
        $validatedItems[] = [
            'product_id' => $productId,
            'name' => $item['name'] ?? '',
            'price' => $productPrice,
            'quantity' => $quantity,
            'size' => $item['size'] ?? ''
        ];
    }
    
    // Build URLs from provided origin
    $successUrl = $originUrl . '/php_app/checkout-success.php?session_id={CHECKOUT_SESSION_ID}';
    $cancelUrl = $originUrl . '/php_app/checkout-cancel.php';
    
    // For test mode, simulate Stripe checkout
    $sessionId = 'cs_test_' . bin2hex(random_bytes(16));
    
    // Store order in database
    $orderModel->create($sessionId, $validatedItems, $totalAmount);
    
    // In production, this would redirect to Stripe
    // For now, simulate with a test URL
    jsonResponse([
        'url' => $successUrl,
        'session_id' => $sessionId
    ]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sessionId = isset($_GET['session_id']) ? $_GET['session_id'] : null;
    
    if (!$sessionId) {
        jsonResponse(['error' => 'Session ID required'], 400);
    }
    
    $order = $orderModel->getBySessionId($sessionId);
    
    if (!$order) {
        jsonResponse(['error' => 'Order not found'], 404);
    }
    
    // For test mode, automatically mark as paid
    if ($order['payment_status'] === 'pending') {
        $orderModel->updateStatus($sessionId, 'complete', 'paid');
        $order['status'] = 'complete';
        $order['payment_status'] = 'paid';
    }
    
    jsonResponse([
        'status' => $order['status'],
        'payment_status' => $order['payment_status'],
        'amount_total' => floatval($order['total_amount']) * 100,
        'currency' => 'usd'
    ]);
    
} else {
    jsonResponse(['error' => 'Method not allowed'], 405);
}
