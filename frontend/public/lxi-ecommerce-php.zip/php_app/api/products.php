<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/models.php';

setCorsHeaders();

$productModel = new Product();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $category = isset($_GET['category']) ? $_GET['category'] : null;
    $products = $productModel->getAll($category);
    jsonResponse(['products' => $products, 'count' => count($products)]);
} else {
    jsonResponse(['error' => 'Method not allowed'], 405);
}
