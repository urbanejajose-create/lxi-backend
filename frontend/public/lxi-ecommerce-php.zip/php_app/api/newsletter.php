<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/models.php';

setCorsHeaders();

$newsletter = new Newsletter();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = getJsonInput();
    
    if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['error' => 'Invalid email address'], 400);
    }
    
    $result = $newsletter->subscribe($data['email']);
    
    if ($result) {
        jsonResponse(['message' => 'Successfully subscribed', 'email' => $data['email']]);
    } else {
        jsonResponse(['error' => 'Email already subscribed'], 400);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $subscribers = $newsletter->getAll();
    jsonResponse(['subscribers' => $subscribers, 'count' => count($subscribers)]);
} else {
    jsonResponse(['error' => 'Method not allowed'], 405);
}
