-- =====================================================
-- LXI E-COMMERCE DATABASE SETUP
-- Run this in phpMyAdmin on your Namecheap hosting
-- =====================================================

CREATE DATABASE IF NOT EXISTS lxi_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lxi_store;

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    slug VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    tag VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    description TEXT,
    long_description TEXT,
    sizes VARCHAR(100) DEFAULT 'S,M,L,XL',
    material_details TEXT,
    embroidery_details TEXT,
    sizing_details TEXT,
    shipping_details TEXT,
    image1 VARCHAR(255),
    image2 VARCHAR(255),
    image3 VARCHAR(255),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Newsletter subscribers
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(255) UNIQUE,
    customer_email VARCHAR(100),
    items JSON,
    total_amount DECIMAL(10,2),
    currency VARCHAR(10) DEFAULT 'usd',
    status VARCHAR(50) DEFAULT 'pending',
    payment_status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert default admin user
-- Username: admin | Password: admin123
-- IMPORTANT: Change this password after first login!
INSERT INTO admin_users (username, password, email) VALUES 
('admin', '$2y$10$zXBtwdMSIxF0symOHaF2F.qWdcdwxfAN1.t0CR9Ho4N58d8uxRj1m', 'admin@lxi.com');

-- Insert sample products (Drop 01 - Founders Edition)
INSERT INTO products (slug, name, category, tag, price, description, long_description, sizes, material_details, embroidery_details, sizing_details, shipping_details, image1, image2, image3) VALUES
('heavyweight-tee', 'HEAVYWEIGHT TEE', 'TOPS', 'TOPS · FOUNDERS', 59.00, 'No es una camiseta. Es la primera pieza de tu armadura.', 'La Heavyweight Tee LXI representa el inicio de tu transformación. Diseñada para quienes entienden que la presencia comienza en los detalles.', 'S,M,L,XL', '100% ring-spun cotton, 6.1oz. Garment dyed for depth of color. Embroidered LXI crest, not printed.', 'Three-point signature: chest crest (3"), sleeve mark (1"), back inscription "LUCHANDO" in roman letterforms.', 'Cut for presence. Slightly oversized by design. Model wears size M at 6\'1".', 'Produced on demand. Ships in 3-7 business days. Final sale — each piece made for you.', 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&q=80', 'https://images.unsplash.com/photo-1562135291-7728cc647783?w=800&q=80', 'https://images.unsplash.com/photo-1529720317453-c8da503f2051?w=800&q=80'),

('snapback-hat', 'SNAPBACK HAT', 'HEADWEAR', 'HEADWEAR · FOUNDERS', 45.00, 'Corona tu transformación.', 'El Snapback LXI lleva el emblema del gladiador moderno. Un recordatorio silencioso de la batalla que eligiste enfrentar.', 'ONE SIZE', 'Premium structured snapback. 6-panel construction. Embroidered gladiator crest in imperial gold.', 'Front panel: LXI gladiator emblem (2.5"). Side panel: Roman numeral "LXI".', 'Adjustable snapback closure. One size fits most.', 'Produced on demand. Ships in 3-7 business days. Final sale — each piece made for you.', 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=800&q=80', 'https://images.unsplash.com/photo-1556306535-0f09a537f0a3?w=800&q=80', NULL),

('eco-hoodie', 'ECO HOODIE ESSENTIAL', 'OUTERWEAR', 'OUTERWEAR · FOUNDERS', 89.00, 'La armadura esencial del gladiador moderno.', 'El Eco Hoodie LXI combina sustentabilidad con presencia. Fabricado para los que entienden que el verdadero poder no necesita anunciarse.', 'S,M,L,XL', 'Organic cotton blend. 320gsm premium weight. Brushed fleece interior for comfort.', 'Chest crest (3.5") in imperial gold. Sleeve detail with "LUCHANDO" inscription.', 'Relaxed fit. Dropped shoulders. Model wears size M at 6\'1".', 'Produced on demand. Ships in 3-7 business days. Final sale — each piece made for you.', 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&q=80', 'https://images.unsplash.com/photo-1669202786389-9f69f67deff7?w=800&q=80', NULL),

('cuffed-beanie', 'CUFFED BEANIE', 'HEADWEAR', 'HEADWEAR · FOUNDERS', 45.00, 'Silencio y presencia.', 'El Beanie LXI para los que operan en silencio. El emblema del gladiador bordado como declaración sutil de identidad.', 'ONE SIZE', 'Premium acrylic blend. Cuffed design. Embroidered gladiator crest in imperial gold.', 'Center front: LXI gladiator emblem (2") with laurel wreath detail.', 'One size fits most. Stretchable cuff construction.', 'Produced on demand. Ships in 3-7 business days. Final sale — each piece made for you.', 'https://images.unsplash.com/photo-1576871337622-98d48d1cf531?w=800&q=80', 'https://images.unsplash.com/photo-1579748138079-6d2d7d63db63?w=800&q=80', NULL),

('long-sleeve-shirt', 'LONG SLEEVE SHIRT', 'TOPS', 'TOPS · FOUNDERS', 65.00, 'Para las batallas que requieren paciencia.', 'La Long Sleeve LXI extiende la armadura. Para los días largos, las batallas prolongadas, y los que entienden que la consistencia es la verdadera victoria.', 'S,M,L,XL', '100% cotton jersey. 180gsm. Ribbed cuffs and collar.', 'Sleeve crest (1.5") in imperial gold. Subtle "LXI" inscription at hem.', 'Regular fit with slightly elongated body. Model wears size M at 6\'1".', 'Produced on demand. Ships in 3-7 business days. Final sale — each piece made for you.', 'https://images.unsplash.com/photo-1529720317453-c8da503f2051?w=800&q=80', 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800&q=80', NULL);

SELECT 'Database setup complete!' as Status;
