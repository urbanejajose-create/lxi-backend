<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/models.php';

// Check if already logged in
if (isset($_SESSION['admin_id'])) {
    header('Location: /php_app/admin/');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $admin = new Admin();
    $user = $admin->authenticate($username, $password);
    
    if ($user) {
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_username'] = $user['username'];
        header('Location: /php_app/admin/');
        exit;
    } else {
        $error = 'Credenciales inválidas';
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - LXI</title>
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
    <style>
        .login-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .login-box {
            width: 100%;
            max-width: 400px;
            background: var(--lxi-secondary-bg);
            border: 1px solid var(--lxi-border);
            padding: 48px;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 48px;
        }
        .login-logo a {
            color: var(--lxi-accent-gold);
            font-family: 'Cormorant Garamond', serif;
            font-size: 36px;
            letter-spacing: 0.3em;
            text-decoration: none;
        }
        .login-title {
            text-align: center;
            color: var(--lxi-primary-text);
            font-size: 14px;
            letter-spacing: 0.2em;
            margin-bottom: 32px;
        }
        .login-form {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .form-group label {
            color: var(--lxi-secondary-text);
            font-size: 11px;
            letter-spacing: 0.2em;
        }
        .form-group input {
            background: var(--lxi-primary-bg);
            border: 1px solid var(--lxi-border);
            color: var(--lxi-primary-text);
            padding: 14px 16px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--lxi-accent-gold);
        }
        .error-message {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid #ef4444;
            color: #ef4444;
            padding: 12px;
            font-size: 12px;
            text-align: center;
        }
    </style>
</head>
<body>
    <main class="login-page">
        <div class="login-box">
            <div class="login-logo">
                <a href="/php_app/">LXI</a>
            </div>
            
            <h1 class="login-title">ADMIN PANEL</h1>
            
            <?php if ($error): ?>
            <div class="error-message"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <form method="POST" class="login-form">
                <div class="form-group">
                    <label>USERNAME</label>
                    <input type="text" name="username" required autofocus>
                </div>
                
                <div class="form-group">
                    <label>PASSWORD</label>
                    <input type="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-gold-fill" style="margin-top: 16px;">
                    ENTER
                </button>
            </form>
        </div>
    </main>
</body>
</html>
