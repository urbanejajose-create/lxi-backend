<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/models.php';

requireAdmin();

$productModel = new Product();
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'update') {
        $data = [
            'slug' => $_POST['slug'] ?? '',
            'name' => $_POST['name'] ?? '',
            'category' => $_POST['category'] ?? '',
            'tag' => $_POST['tag'] ?? '',
            'price' => floatval($_POST['price'] ?? 0),
            'description' => $_POST['description'] ?? '',
            'long_description' => $_POST['long_description'] ?? '',
            'sizes' => $_POST['sizes'] ?? 'S,M,L,XL',
            'material_details' => $_POST['material_details'] ?? '',
            'embroidery_details' => $_POST['embroidery_details'] ?? '',
            'sizing_details' => $_POST['sizing_details'] ?? '',
            'shipping_details' => $_POST['shipping_details'] ?? '',
            'image1' => $_POST['image1'] ?? '',
            'image2' => $_POST['image2'] ?? '',
            'image3' => $_POST['image3'] ?? '',
        ];
        
        // Handle file uploads
        for ($i = 1; $i <= 3; $i++) {
            if (isset($_FILES["image{$i}_file"]) && $_FILES["image{$i}_file"]['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../uploads/products/';
                $fileName = uniqid() . '_' . basename($_FILES["image{$i}_file"]['name']);
                $uploadPath = $uploadDir . $fileName;
                
                if (move_uploaded_file($_FILES["image{$i}_file"]['tmp_name'], $uploadPath)) {
                    $data["image{$i}"] = '/php_app/uploads/products/' . $fileName;
                }
            }
        }
        
        if ($action === 'create') {
            if ($productModel->create($data)) {
                $message = 'Product created successfully';
            } else {
                $error = 'Failed to create product';
            }
        } else {
            $productId = intval($_POST['id'] ?? 0);
            if ($productModel->update($productId, $data)) {
                $message = 'Product updated successfully';
            } else {
                $error = 'Failed to update product';
            }
        }
    } elseif ($action === 'delete') {
        $productId = intval($_POST['id'] ?? 0);
        if ($productModel->delete($productId)) {
            $message = 'Product deleted successfully';
        } else {
            $error = 'Failed to delete product';
        }
    }
}

// Get edit product if editing
$editProduct = null;
if (isset($_GET['edit'])) {
    $editProduct = $productModel->getById(intval($_GET['edit']));
}

$products = $productModel->getAll();
$categories = ['TOPS', 'HEADWEAR', 'OUTERWEAR'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Admin - LXI</title>
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
    <link rel="stylesheet" href="/php_app/admin/admin.css">
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="admin-logo">
                <a href="/php_app/">LXI</a>
                <span>ADMIN</span>
            </div>
            <nav class="admin-nav">
                <a href="/php_app/admin/" class="admin-nav-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="7" height="7"></rect>
                        <rect x="14" y="3" width="7" height="7"></rect>
                        <rect x="14" y="14" width="7" height="7"></rect>
                        <rect x="3" y="14" width="7" height="7"></rect>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="/php_app/admin/products.php" class="admin-nav-link active">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                    </svg>
                    <span>Products</span>
                </a>
                <a href="/php_app/admin/orders.php" class="admin-nav-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                    <span>Orders</span>
                </a>
                <a href="/php_app/admin/subscribers.php" class="admin-nav-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                    <span>Subscribers</span>
                </a>
            </nav>
            <div class="admin-sidebar-footer">
                <a href="/php_app/admin/logout.php" class="admin-logout">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                        <polyline points="16 17 21 12 16 7"></polyline>
                        <line x1="21" y1="12" x2="9" y2="12"></line>
                    </svg>
                    <span>Logout</span>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-main">
            <?php if ($message): ?>
            <div class="alert success"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
            <div class="alert error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            
            <?php if ($editProduct || isset($_GET['new'])): ?>
            <!-- Product Form -->
            <div class="page-actions">
                <h1><?= $editProduct ? 'Edit Product' : 'New Product' ?></h1>
                <a href="/php_app/admin/products.php" class="btn btn-gold-outline" style="padding: 12px 24px;">Cancel</a>
            </div>
            
            <form method="POST" enctype="multipart/form-data" class="admin-form">
                <input type="hidden" name="action" value="<?= $editProduct ? 'update' : 'create' ?>">
                <?php if ($editProduct): ?>
                <input type="hidden" name="id" value="<?= $editProduct['id'] ?>">
                <?php endif; ?>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>PRODUCT NAME *</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label>SLUG (URL) *</label>
                        <input type="text" name="slug" value="<?= htmlspecialchars($editProduct['slug'] ?? '') ?>" required <?= $editProduct ? 'readonly' : '' ?>>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>CATEGORY *</label>
                        <select name="category" required>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat ?>" <?= ($editProduct['category'] ?? '') === $cat ? 'selected' : '' ?>>
                                <?= $cat ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>PRICE ($) *</label>
                        <input type="number" name="price" step="0.01" value="<?= htmlspecialchars($editProduct['price'] ?? '') ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>TAG</label>
                        <input type="text" name="tag" value="<?= htmlspecialchars($editProduct['tag'] ?? '') ?>" placeholder="e.g., TOPS · FOUNDERS">
                    </div>
                    <div class="form-group">
                        <label>SIZES</label>
                        <input type="text" name="sizes" value="<?= htmlspecialchars($editProduct['sizes'] ?? 'S,M,L,XL') ?>" placeholder="S,M,L,XL or ONE SIZE">
                    </div>
                </div>
                
                <div class="form-group full-width">
                    <label>SHORT DESCRIPTION</label>
                    <textarea name="description"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group full-width">
                    <label>LONG DESCRIPTION</label>
                    <textarea name="long_description"><?= htmlspecialchars($editProduct['long_description'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group full-width">
                    <label>MATERIAL DETAILS</label>
                    <textarea name="material_details"><?= htmlspecialchars($editProduct['material_details'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group full-width">
                    <label>EMBROIDERY DETAILS</label>
                    <textarea name="embroidery_details"><?= htmlspecialchars($editProduct['embroidery_details'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group full-width">
                    <label>SIZING DETAILS</label>
                    <textarea name="sizing_details"><?= htmlspecialchars($editProduct['sizing_details'] ?? '') ?></textarea>
                </div>
                
                <div class="form-group full-width">
                    <label>SHIPPING DETAILS</label>
                    <textarea name="shipping_details"><?= htmlspecialchars($editProduct['shipping_details'] ?? '') ?></textarea>
                </div>
                
                <h3 style="color: var(--lxi-primary-text); font-size: 16px; margin-top: 16px;">Product Images</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>IMAGE 1 (Primary)</label>
                        <input type="text" name="image1" value="<?= htmlspecialchars($editProduct['image1'] ?? '') ?>" placeholder="Image URL">
                        <input type="file" name="image1_file" accept="image/*" style="margin-top: 8px;">
                        <?php if (!empty($editProduct['image1'])): ?>
                        <img src="<?= htmlspecialchars($editProduct['image1']) ?>" style="width: 100px; height: 100px; object-fit: cover; margin-top: 8px; border: 1px solid var(--lxi-border);">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>IMAGE 2</label>
                        <input type="text" name="image2" value="<?= htmlspecialchars($editProduct['image2'] ?? '') ?>" placeholder="Image URL">
                        <input type="file" name="image2_file" accept="image/*" style="margin-top: 8px;">
                        <?php if (!empty($editProduct['image2'])): ?>
                        <img src="<?= htmlspecialchars($editProduct['image2']) ?>" style="width: 100px; height: 100px; object-fit: cover; margin-top: 8px; border: 1px solid var(--lxi-border);">
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>IMAGE 3</label>
                    <input type="text" name="image3" value="<?= htmlspecialchars($editProduct['image3'] ?? '') ?>" placeholder="Image URL">
                    <input type="file" name="image3_file" accept="image/*" style="margin-top: 8px;">
                    <?php if (!empty($editProduct['image3'])): ?>
                    <img src="<?= htmlspecialchars($editProduct['image3']) ?>" style="width: 100px; height: 100px; object-fit: cover; margin-top: 8px; border: 1px solid var(--lxi-border);">
                    <?php endif; ?>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-gold-fill">
                        <?= $editProduct ? 'UPDATE PRODUCT' : 'CREATE PRODUCT' ?>
                    </button>
                </div>
            </form>
            
            <?php else: ?>
            <!-- Products List -->
            <div class="page-actions">
                <h1>Products</h1>
                <a href="/php_app/admin/products.php?new=1" class="btn btn-gold-fill" style="padding: 12px 24px;">+ Add Product</a>
            </div>
            
            <div class="product-grid-admin">
                <?php foreach ($products as $product): ?>
                <div class="product-card-admin">
                    <img src="<?= htmlspecialchars($product['image1']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    <div class="product-card-admin-info">
                        <div class="product-card-admin-name"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="product-card-admin-price">$<?= number_format($product['price'], 2) ?></div>
                        <div class="product-card-admin-actions">
                            <a href="/php_app/admin/products.php?edit=<?= $product['id'] ?>" class="btn btn-gold-outline" style="padding: 8px 16px; font-size: 10px;">
                                Edit
                            </a>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $product['id'] ?>">
                                <button type="submit" class="btn" style="padding: 8px 16px; font-size: 10px; color: #ef4444; border: 1px solid #ef4444;">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
