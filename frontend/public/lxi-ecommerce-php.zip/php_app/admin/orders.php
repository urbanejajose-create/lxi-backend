<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/models.php';

requireAdmin();

$orderModel = new Order();
$orders = $orderModel->getAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Admin - LXI</title>
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
    <link rel="stylesheet" href="/php_app/admin/admin.css">
</head>
<body>
    <div class="admin-layout">
        <aside class="admin-sidebar">
            <div class="admin-logo">
                <a href="/php_app/">LXI</a>
                <span>ADMIN</span>
            </div>
            <nav class="admin-nav">
                <a href="/php_app/admin/" class="admin-nav-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="7" height="7"></rect>
                        <rect x="14" y="3" width="7" height="7"></rect>
                        <rect x="14" y="14" width="7" height="7"></rect>
                        <rect x="3" y="14" width="7" height="7"></rect>
                    </svg>
                    <span>Dashboard</span>
                </a>
                <a href="/php_app/admin/products.php" class="admin-nav-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                    </svg>
                    <span>Products</span>
                </a>
                <a href="/php_app/admin/orders.php" class="admin-nav-link active">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                        <line x1="3" y1="6" x2="21" y2="6"></line>
                        <path d="M16 10a4 4 0 0 1-8 0"></path>
                    </svg>
                    <span>Orders</span>
                </a>
                <a href="/php_app/admin/subscribers.php" class="admin-nav-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                    <span>Subscribers</span>
                </a>
            </nav>
            <div class="admin-sidebar-footer">
                <a href="/php_app/admin/logout.php" class="admin-logout">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                        <polyline points="16 17 21 12 16 7"></polyline>
                        <line x1="21" y1="12" x2="9" y2="12"></line>
                    </svg>
                    <span>Logout</span>
                </a>
            </div>
        </aside>
        
        <main class="admin-main">
            <div class="page-actions">
                <h1>Orders</h1>
            </div>
            
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Date</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): 
                            $items = json_decode($order['items'], true) ?? [];
                        ?>
                        <tr>
                            <td><code><?= htmlspecialchars(substr($order['session_id'], 0, 24)) ?>...</code></td>
                            <td><?= date('M d, Y H:i', strtotime($order['created_at'])) ?></td>
                            <td>
                                <?php foreach ($items as $item): ?>
                                <div style="font-size: 12px; margin-bottom: 4px;">
                                    <?= htmlspecialchars($item['name']) ?> (<?= $item['size'] ?>) x<?= $item['quantity'] ?>
                                </div>
                                <?php endforeach; ?>
                            </td>
                            <td>$<?= number_format($order['total_amount'], 2) ?></td>
                            <td>
                                <span class="status-badge <?= $order['payment_status'] === 'paid' ? 'success' : 'pending' ?>">
                                    <?= ucfirst($order['payment_status']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($orders)): ?>
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--lxi-secondary-text); padding: 48px;">
                                No orders yet
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
