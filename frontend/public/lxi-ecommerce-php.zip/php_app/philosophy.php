<?php
require_once __DIR__ . '/includes/config.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>La Filosofía LXI</title>
    <meta name="description" content="El gladiador no entra a la arena porque no tiene miedo. Entra porque decidió que la batalla vale más que el miedo.">
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar scrolled">
        <div class="container">
            <div class="navbar-inner">
                <a href="/php_app/" class="logo">LXI</a>
                <ul class="nav-links">
                    <li><a href="/php_app/shop.php" class="nav-link">SHOP</a></li>
                    <li><a href="/php_app/philosophy.php" class="nav-link">PHILOSOPHY</a></li>
                    <li><a href="/php_app/shop.php" class="nav-link">DROP 01</a></li>
                </ul>
                <div class="nav-actions">
                    <button class="cart-btn" aria-label="Open cart">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" style="display: none;">0</span>
                    </button>
                    <button class="mobile-menu-btn" aria-label="Open menu">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="3" y1="12" x2="21" y2="12"></line>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <line x1="3" y1="18" x2="21" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <button class="mobile-menu-close" aria-label="Close menu">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
        <ul class="mobile-menu-links">
            <li><a href="/php_app/shop.php" class="mobile-menu-link">SHOP</a></li>
            <li><a href="/php_app/philosophy.php" class="mobile-menu-link">PHILOSOPHY</a></li>
            <li><a href="/php_app/shop.php" class="mobile-menu-link">DROP 01</a></li>
        </ul>
    </div>
    
    <main data-testid="philosophy-page">
        <!-- Hero -->
        <section class="philosophy-hero">
            <div class="philosophy-hero-bg" style="background-image: url('https://images.unsplash.com/photo-1648314789571-4003c96b5b09?w=1920&q=80');"></div>
            <div class="philosophy-hero-overlay"></div>
            <div class="philosophy-hero-content">
                <span class="micro-label">LA FILOSOFÍA LXI</span>
            </div>
        </section>
        
        <!-- Manifesto -->
        <section class="manifesto-section">
            <div class="container">
                <div class="manifesto-content">
                    <!-- Opening Quote -->
                    <blockquote class="manifesto-quote">
                        "El gladiador no entra a la arena porque no tiene miedo. Entra porque decidió que la batalla vale más que el miedo."
                    </blockquote>
                    
                    <!-- Act I -->
                    <div class="manifesto-act">
                        <span class="micro-label">ACT I</span>
                        <h2 class="manifesto-act-title">EL ORIGEN</h2>
                        <div class="manifesto-act-text">
                            <p>LXI nació de un libro. De una batalla personal escrita para millones que pelean la misma guerra silenciosa: el síndrome del impostor.</p>
                            <p>"Luchando con el Impostor" no es una metáfora. Es un método. Y LXI es su armadura.</p>
                        </div>
                    </div>
                    
                    <!-- Act II -->
                    <div class="manifesto-act">
                        <span class="micro-label">ACT II</span>
                        <h2 class="manifesto-act-title">LA TRANSFORMACIÓN</h2>
                        <div class="manifesto-act-text">
                            <p>Existen dos tipos de personas en cualquier arena: los que esperan sentirse listos para entrar, y los que entran sabiendo que el miedo nunca desaparece.</p>
                            <p>LXI viste a los segundos.</p>
                        </div>
                    </div>
                    
                    <!-- Act III -->
                    <div class="manifesto-act">
                        <span class="micro-label">ACT III</span>
                        <h2 class="manifesto-act-title">EL ESTÁNDAR</h2>
                        <div class="manifesto-act-text">
                            <p>Cada pieza LXI es diseñada bajo un solo criterio: ¿Tiene la presencia silenciosa de quien ya ganó su primera batalla?</p>
                            <p>Si la respuesta es no, no existe.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Brand Values -->
        <section class="brand-values-section">
            <div class="container">
                <div class="brand-values-header">
                    <span class="micro-label">LOS VALORES</span>
                    <h2 class="brand-values-title">Cinco Pilares</h2>
                </div>
                
                <div class="brand-values-list">
                    <div class="brand-value-item">
                        <span class="brand-value-numeral">I</span>
                        <div>
                            <h3 class="brand-value-name">ARENA</h3>
                            <p class="brand-value-desc">El espacio donde decides aparecer. No el escenario que te espera, sino el que construyes con cada decisión.</p>
                        </div>
                    </div>
                    
                    <div class="brand-value-item">
                        <span class="brand-value-numeral">II</span>
                        <div>
                            <h3 class="brand-value-name">DISCIPLINA</h3>
                            <p class="brand-value-desc">La consistencia silenciosa que construye identidad. No lo que haces cuando te observan, sino lo que repites cuando nadie mira.</p>
                        </div>
                    </div>
                    
                    <div class="brand-value-item">
                        <span class="brand-value-numeral">III</span>
                        <div>
                            <h3 class="brand-value-name">PRESENCIA</h3>
                            <p class="brand-value-desc">La autoridad que no necesita anunciarse. El poder de ocupar un espacio sin pedirlo ni disculparte.</p>
                        </div>
                    </div>
                    
                    <div class="brand-value-item">
                        <span class="brand-value-numeral">IV</span>
                        <div>
                            <h3 class="brand-value-name">TRANSFORMACIÓN</h3>
                            <p class="brand-value-desc">El proceso, no el destino. El arte de convertirte en quien decidiste ser, una batalla a la vez.</p>
                        </div>
                    </div>
                    
                    <div class="brand-value-item">
                        <span class="brand-value-numeral">V</span>
                        <div>
                            <h3 class="brand-value-name">LEGADO</h3>
                            <p class="brand-value-desc">Lo que permanece cuando el miedo desaparece. La huella que dejas en los que te observan pelear.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <!-- Mission & Vision -->
        <section class="mission-vision-section">
            <div class="container">
                <div class="mission-vision-box">
                    <div class="mission-vision-grid">
                        <div class="mission-vision-item">
                            <span class="micro-label">MISIÓN</span>
                            <p>Vestir la transformación de quienes eligieron enfrentar su arena.</p>
                        </div>
                        <div class="mission-vision-item">
                            <span class="micro-label">VISIÓN</span>
                            <p>Ser la marca que los gladiadores modernos reconocen como suya.</p>
                        </div>
                    </div>
                </div>
                
                <div class="philosophy-cta">
                    <a href="/php_app/shop.php" class="view-more" data-testid="shop-cta">
                        EXPLORE THE COLLECTION
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
        </section>
    </main>
    
    <?php include __DIR__ . '/includes/footer.php'; ?>
    <?php include __DIR__ . '/includes/cart-drawer.php'; ?>
    
    <script src="/php_app/assets/js/main.js"></script>
</body>
</html>
