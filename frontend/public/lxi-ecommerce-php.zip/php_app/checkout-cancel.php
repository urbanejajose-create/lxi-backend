<?php
require_once __DIR__ . '/includes/config.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Cancelado - LXI</title>
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
</head>
<body>
    <main class="checkout-page" data-testid="checkout-cancel-page">
        <div class="checkout-content">
            <div class="checkout-icon" style="opacity: 0.5;">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="15" y1="9" x2="9" y2="15"></line>
                    <line x1="9" y1="9" x2="15" y2="15"></line>
                </svg>
            </div>
            
            <span class="micro-label">PAGO CANCELADO</span>
            
            <h1 class="checkout-title">Tu orden fue cancelada</h1>
            
            <p class="checkout-text">
                No te preocupes, tu armadura te espera. Los artículos siguen en tu carrito.
            </p>
            
            <div style="display: flex; flex-direction: column; gap: 16px; align-items: center;">
                <a href="/php_app/shop.php" class="btn btn-gold-outline" data-testid="return-to-shop-link">
                    RETURN TO SHOP
                </a>
                
                <a href="/php_app/" class="view-more">
                    GO HOME
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </main>
    
    <script src="/php_app/assets/js/main.js"></script>
</body>
</html>
