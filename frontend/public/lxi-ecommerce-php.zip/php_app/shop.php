<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/models.php';

$productModel = new Product();
$category = isset($_GET['category']) ? $_GET['category'] : null;
$products = $productModel->getAll($category);
$categories = ['ALL', 'TOPS', 'HEADWEAR', 'OUTERWEAR'];
$currentCategory = $category ?: 'ALL';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - LXI | Drop 01 Founders Edition</title>
    <meta name="description" content="Explore Drop 01 - Founders Edition. Premium apparel for modern gladiators.">
    <link rel="stylesheet" href="/php_app/assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar scrolled">
        <div class="container">
            <div class="navbar-inner">
                <a href="/php_app/" class="logo">LXI</a>
                <ul class="nav-links">
                    <li><a href="/php_app/shop.php" class="nav-link">SHOP</a></li>
                    <li><a href="/php_app/philosophy.php" class="nav-link">PHILOSOPHY</a></li>
                    <li><a href="/php_app/shop.php" class="nav-link">DROP 01</a></li>
                </ul>
                <div class="nav-actions">
                    <button class="cart-btn" aria-label="Open cart">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <path d="M16 10a4 4 0 0 1-8 0"></path>
                        </svg>
                        <span class="cart-count" style="display: none;">0</span>
                    </button>
                    <button class="mobile-menu-btn" aria-label="Open menu">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="3" y1="12" x2="21" y2="12"></line>
                            <line x1="3" y1="6" x2="21" y2="6"></line>
                            <line x1="3" y1="18" x2="21" y2="18"></line>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <button class="mobile-menu-close" aria-label="Close menu">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
        <ul class="mobile-menu-links">
            <li><a href="/php_app/shop.php" class="mobile-menu-link">SHOP</a></li>
            <li><a href="/php_app/philosophy.php" class="mobile-menu-link">PHILOSOPHY</a></li>
            <li><a href="/php_app/shop.php" class="mobile-menu-link">DROP 01</a></li>
        </ul>
    </div>
    
    <main data-testid="shop-page" style="padding-top: 128px; padding-bottom: 96px; min-height: 100vh;">
        <div class="container">
            <!-- Header -->
            <div class="page-header" style="padding-top: 0;">
                <h1 class="page-title" data-testid="shop-title">DROP 01</h1>
                <p class="micro-label" style="margin-top: 16px;">FOUNDERS EDITION — <?= count($products) ?> PIECES</p>
            </div>
            
            <!-- Category Filter -->
            <div class="category-filter" data-testid="category-filter">
                <?php foreach ($categories as $cat): ?>
                <button class="filter-btn <?= $currentCategory === $cat ? 'active' : '' ?>" 
                        data-category="<?= $cat ?>"
                        data-testid="filter-<?= strtolower($cat) ?>"
                        onclick="filterProducts('<?= $cat ?>')">
                    <?= $cat ?>
                </button>
                <?php endforeach; ?>
            </div>
            
            <!-- Product Grid -->
            <div class="product-grid" data-testid="product-grid">
                <?php foreach ($products as $product): ?>
                <a href="/php_app/product.php?slug=<?= htmlspecialchars($product['slug']) ?>" 
                   class="product-card"
                   data-testid="product-card-<?= htmlspecialchars($product['slug']) ?>">
                    <div class="product-card-image">
                        <img src="<?= htmlspecialchars($product['image1']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                        <div class="product-card-tag">
                            <span class="micro-label"><?= htmlspecialchars($product['tag']) ?></span>
                        </div>
                        <div class="product-card-overlay">
                            <span>VIEW PIECE</span>
                        </div>
                    </div>
                    <div class="product-card-info">
                        <h3 class="product-card-name" data-testid="product-name-<?= htmlspecialchars($product['slug']) ?>">
                            <?= htmlspecialchars($product['name']) ?>
                        </h3>
                        <p class="product-card-price" data-testid="product-price-<?= htmlspecialchars($product['slug']) ?>">
                            $<?= number_format($product['price'], 0) ?>
                        </p>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            
            <!-- Drop Banner -->
            <div class="drop-banner" data-testid="drop-banner" style="margin-top: 96px;">
                <span class="micro-label">FOUNDERS EDITION — AVAILABLE FOR LIMITED TIME</span>
                <p class="drop-banner-text">PRODUCED ON DEMAND · SHIPS VIA PRINTFUL</p>
            </div>
        </div>
    </main>
    
    <?php include __DIR__ . '/includes/footer.php'; ?>
    <?php include __DIR__ . '/includes/cart-drawer.php'; ?>
    
    <script src="/php_app/assets/js/main.js"></script>
</body>
</html>
