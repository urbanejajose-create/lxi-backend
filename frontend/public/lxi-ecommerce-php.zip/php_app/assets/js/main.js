// LXI E-commerce JavaScript

// Cart State
let cart = JSON.parse(localStorage.getItem('lxi_cart')) || [];
const FREE_SHIPPING_THRESHOLD = 150;

// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    initNavbar();
    initCart();
    initMobileMenu();
    initAccordions();
    initNewsletterForm();
    initSizeSelector();
    initProductGallery();
    updateCartUI();
});

// Navbar scroll effect
function initNavbar() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
}

// Mobile Menu
function initMobileMenu() {
    const menuBtn = document.querySelector('.mobile-menu-btn');
    const closeBtn = document.querySelector('.mobile-menu-close');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', () => mobileMenu.classList.add('active'));
    }
    
    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => mobileMenu.classList.remove('active'));
    }
    
    // Close on link click
    document.querySelectorAll('.mobile-menu-link').forEach(link => {
        link.addEventListener('click', () => mobileMenu?.classList.remove('active'));
    });
}

// Cart Functions
function initCart() {
    const cartBtn = document.querySelector('.cart-btn');
    const cartOverlay = document.querySelector('.cart-overlay');
    const cartDrawer = document.querySelector('.cart-drawer');
    const cartClose = document.querySelector('.cart-close');
    
    if (cartBtn) {
        cartBtn.addEventListener('click', () => openCart());
    }
    
    if (cartOverlay) {
        cartOverlay.addEventListener('click', () => closeCart());
    }
    
    if (cartClose) {
        cartClose.addEventListener('click', () => closeCart());
    }
}

function openCart() {
    document.querySelector('.cart-overlay')?.classList.add('active');
    document.querySelector('.cart-drawer')?.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCart() {
    document.querySelector('.cart-overlay')?.classList.remove('active');
    document.querySelector('.cart-drawer')?.classList.remove('active');
    document.body.style.overflow = '';
}

function addToCart(product) {
    const existingIndex = cart.findIndex(item => 
        item.id === product.id && item.size === product.size
    );
    
    if (existingIndex > -1) {
        cart[existingIndex].quantity += product.quantity || 1;
    } else {
        cart.push({
            ...product,
            quantity: product.quantity || 1
        });
    }
    
    saveCart();
    updateCartUI();
    showToast('Añadido a tu armadura', 'success');
    openCart();
}

function removeFromCart(id, size) {
    cart = cart.filter(item => !(item.id === id && item.size === size));
    saveCart();
    updateCartUI();
}

function updateQuantity(id, size, quantity) {
    const item = cart.find(item => item.id === id && item.size === size);
    if (item) {
        item.quantity = Math.max(1, quantity);
        saveCart();
        updateCartUI();
    }
}

function saveCart() {
    localStorage.setItem('lxi_cart', JSON.stringify(cart));
}

function getCartTotal() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

function getCartCount() {
    return cart.reduce((total, item) => total + item.quantity, 0);
}

function updateCartUI() {
    // Update cart count
    const countElements = document.querySelectorAll('.cart-count');
    const count = getCartCount();
    countElements.forEach(el => {
        el.textContent = count;
        el.style.display = count > 0 ? 'flex' : 'none';
    });
    
    // Update cart items
    const cartItemsContainer = document.querySelector('.cart-items');
    if (!cartItemsContainer) return;
    
    const total = getCartTotal();
    const amountToFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - total);
    
    // Update progress
    const progressText = document.querySelector('.cart-progress p');
    const progressBar = document.querySelector('.progress-bar-fill');
    
    if (progressText) {
        if (amountToFreeShipping > 0) {
            progressText.innerHTML = `Faltan <span>$${amountToFreeShipping.toFixed(2)}</span> para envío gratis`;
        } else {
            progressText.innerHTML = '<span style="letter-spacing: 0.1em;">ENVÍO GRATIS DESBLOQUEADO</span>';
        }
    }
    
    if (progressBar) {
        const percentage = Math.min(100, (total / FREE_SHIPPING_THRESHOLD) * 100);
        progressBar.style.width = `${percentage}%`;
    }
    
    // Update items
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="cart-empty">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
                <p>Tu armadura está vacía.</p>
            </div>
        `;
    } else {
        cartItemsContainer.innerHTML = cart.map(item => `
            <div class="cart-item" data-id="${item.id}" data-size="${item.size}">
                <div class="cart-item-image">
                    <img src="${item.image}" alt="${item.name}">
                </div>
                <div class="cart-item-details">
                    <div class="cart-item-header">
                        <div>
                            <div class="cart-item-name">${item.name}</div>
                            <div class="cart-item-size">Size: ${item.size}</div>
                        </div>
                        <button class="cart-item-remove" onclick="removeFromCart('${item.id}', '${item.size}')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                    <div class="cart-item-footer">
                        <div class="quantity-control">
                            <button class="quantity-btn" onclick="updateQuantity('${item.id}', '${item.size}', ${item.quantity - 1})">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                </svg>
                            </button>
                            <span class="quantity-value">${item.quantity}</span>
                            <button class="quantity-btn" onclick="updateQuantity('${item.id}', '${item.size}', ${item.quantity + 1})">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="12" y1="5" x2="12" y2="19"></line>
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                </svg>
                            </button>
                        </div>
                        <div class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</div>
                    </div>
                </div>
            </div>
        `).join('');
    }
    
    // Update subtotal
    const subtotalElement = document.querySelector('.cart-subtotal span:last-child');
    if (subtotalElement) {
        subtotalElement.textContent = `$${total.toFixed(2)}`;
    }
    
    // Enable/disable checkout button
    const checkoutBtn = document.querySelector('.cart-checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.disabled = cart.length === 0;
        checkoutBtn.style.opacity = cart.length === 0 ? '0.5' : '1';
    }
}

// Checkout
async function proceedToCheckout() {
    if (cart.length === 0) return;
    
    const checkoutBtn = document.querySelector('.cart-checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.disabled = true;
        checkoutBtn.textContent = 'PROCESANDO...';
    }
    
    try {
        const response = await fetch('/php_app/api/checkout.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                items: cart.map(item => ({
                    product_id: item.id,
                    name: item.name,
                    price: item.price,
                    quantity: item.quantity,
                    size: item.size
                })),
                origin_url: window.location.origin
            })
        });
        
        const data = await response.json();
        
        if (data.url) {
            window.location.href = data.url;
        } else {
            throw new Error(data.error || 'Checkout failed');
        }
    } catch (error) {
        console.error('Checkout error:', error);
        showToast('Error al procesar el pago. Intenta de nuevo.', 'error');
        if (checkoutBtn) {
            checkoutBtn.disabled = false;
            checkoutBtn.textContent = 'PROCEED TO ARMOR';
        }
    }
}

// Size Selector
function initSizeSelector() {
    const sizeButtons = document.querySelectorAll('.size-btn');
    sizeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            sizeButtons.forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
        });
    });
}

// Add to Cart from PDP
function handleAddToCart(productData) {
    const selectedSize = document.querySelector('.size-btn.selected');
    
    if (!selectedSize) {
        showToast('Selecciona una talla', 'error');
        return;
    }
    
    addToCart({
        ...productData,
        size: selectedSize.dataset.size
    });
}

// Product Gallery
function initProductGallery() {
    const mainImage = document.querySelector('.product-main-image img');
    const thumbnails = document.querySelectorAll('.product-thumbnail');
    
    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', () => {
            thumbnails.forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
            if (mainImage) {
                mainImage.src = thumb.querySelector('img').src;
            }
        });
    });
}

// Accordions
function initAccordions() {
    const accordions = document.querySelectorAll('.accordion-trigger');
    accordions.forEach(trigger => {
        trigger.addEventListener('click', () => {
            const item = trigger.closest('.accordion-item');
            item.classList.toggle('open');
        });
    });
}

// Newsletter Form
function initNewsletterForm() {
    const form = document.querySelector('.newsletter-form');
    if (!form) return;
    
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const emailInput = form.querySelector('input[type="email"]');
        const submitBtn = form.querySelector('button[type="submit"]');
        const email = emailInput.value.trim();
        
        if (!email) return;
        
        submitBtn.disabled = true;
        submitBtn.textContent = 'ENTRANDO...';
        
        try {
            const response = await fetch('/php_app/api/newsletter.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                showToast('Bienvenido a la arena.', 'success');
                emailInput.value = '';
            } else {
                showToast(data.error || 'Ya eres parte de la comunidad.', 'info');
            }
        } catch (error) {
            showToast('Error al suscribirte. Intenta de nuevo.', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'ENTER THE ARENA';
        }
    });
}

// Toast Notifications
function showToast(message, type = 'info') {
    // Remove existing toast
    const existingToast = document.querySelector('.toast');
    if (existingToast) existingToast.remove();
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            ${type === 'success' 
                ? '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline>'
                : '<circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>'
            }
        </svg>
        <span>${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Remove after delay
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Category Filter
function filterProducts(category) {
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.category === category);
    });
    
    // Update URL
    const url = new URL(window.location);
    if (category === 'ALL') {
        url.searchParams.delete('category');
    } else {
        url.searchParams.set('category', category);
    }
    window.history.pushState({}, '', url);
    
    // Reload or filter products via AJAX
    window.location.reload();
}

// Scroll to content
function scrollToContent() {
    const target = document.getElementById('brand-statement');
    if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
    }
}

// Clear cart after successful purchase
function clearCart() {
    cart = [];
    saveCart();
    updateCartUI();
}

// Check payment status (for success page)
async function checkPaymentStatus(sessionId) {
    const maxAttempts = 5;
    let attempts = 0;
    
    const poll = async () => {
        if (attempts >= maxAttempts) {
            document.querySelector('.checkout-title').textContent = 'Verificación en proceso';
            document.querySelector('.checkout-text').textContent = 'Tu pago está siendo procesado. Recibirás un email de confirmación en breve.';
            return;
        }
        
        try {
            const response = await fetch(`/php_app/api/checkout.php?session_id=${sessionId}`);
            const data = await response.json();
            
            if (data.payment_status === 'paid') {
                clearCart();
                document.querySelector('.checkout-icon').classList.add('success');
                document.querySelector('.checkout-title').textContent = 'Bienvenido a la Arena';
                return;
            } else if (data.status === 'expired') {
                document.querySelector('.checkout-icon').classList.add('error');
                document.querySelector('.checkout-title').textContent = 'Sesión expirada';
                return;
            }
            
            attempts++;
            setTimeout(poll, 2000);
        } catch (error) {
            console.error('Status check error:', error);
            attempts++;
            setTimeout(poll, 2000);
        }
    };
    
    poll();
}
