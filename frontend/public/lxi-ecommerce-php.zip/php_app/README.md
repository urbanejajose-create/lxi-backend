# LXI E-commerce - Guía de Instalación en Namecheap

## Contenido del Paquete

```
lxi-ecommerce/
├── index.php           # Página principal (Home)
├── shop.php            # Catálogo de productos
├── product.php         # Detalle de producto
├── philosophy.php      # Página de filosofía
├── checkout-success.php
├── checkout-cancel.php
├── database.sql        # Script para crear la base de datos
│
├── includes/
│   ├── config.php      # ⚠️ CONFIGURAR CREDENCIALES AQUÍ
│   ├── models.php
│   ├── footer.php
│   └── cart-drawer.php
│
├── api/
│   ├── newsletter.php
│   ├── products.php
│   └── checkout.php
│
├── admin/              # Panel de administración
│   ├── index.php       # Dashboard
│   ├── login.php
│   ├── logout.php
│   ├── products.php    # Gestión de productos
│   ├── orders.php      # Ver pedidos
│   ├── subscribers.php # Ver suscriptores
│   └── admin.css
│
├── assets/
│   ├── css/style.css
│   └── js/main.js
│
└── uploads/
    └── products/       # Carpeta para imágenes subidas
```

---

## Paso 1: Crear Base de Datos en Namecheap

1. Entra a **cPanel** de Namecheap
2. Ve a **MySQL Databases**
3. Crea una nueva base de datos (ej: `tuusuario_lxi`)
4. Crea un usuario MySQL y asígnalo a la base de datos
5. Ve a **phpMyAdmin**
6. Selecciona tu base de datos
7. Haz clic en **Import** y sube el archivo `database.sql`

---

## Paso 2: Configurar Conexión a Base de Datos

Edita el archivo `includes/config.php`:

```php
// CAMBIAR ESTAS LÍNEAS:
define('DB_HOST', 'localhost');
define('DB_NAME', 'tuusuario_lxi');      // Tu nombre de BD
define('DB_USER', 'tuusuario_lxi');      // Tu usuario MySQL
define('DB_PASS', 'tu_contraseña_aqui'); // Tu contraseña MySQL
```

---

## Paso 3: Subir Archivos

1. Conecta por **FTP** o usa el **File Manager** de cPanel
2. Sube TODO el contenido de la carpeta `lxi-ecommerce/` a:
   - `public_html/` (si es tu dominio principal)
   - `public_html/tienda/` (si quieres en subdirectorio)

3. **IMPORTANTE**: Asegúrate que la carpeta `uploads/products/` tenga permisos **755** o **775**

---

## Paso 4: Verificar Instalación

1. Visita tu sitio: `https://tudominio.com/`
2. Deberías ver la página principal de LXI

3. Accede al panel admin: `https://tudominio.com/admin/`
   - **Usuario:** admin
   - **Contraseña:** admin123

4. ⚠️ **CAMBIA LA CONTRASEÑA** después de entrar

---

## Paso 5: Configurar Stripe (Pagos Reales)

Para aceptar pagos reales, necesitas:

1. Crear cuenta en [Stripe](https://stripe.com)
2. Obtener tu **API Key** de Stripe
3. Editar `includes/config.php`:

```php
define('STRIPE_API_KEY', 'sk_live_TU_CLAVE_REAL');
```

4. Editar `api/checkout.php` para usar la API de Stripe real

---

## Estructura de URLs

| URL | Descripción |
|-----|-------------|
| `/` | Página principal |
| `/shop.php` | Catálogo |
| `/shop.php?category=TOPS` | Filtrar por categoría |
| `/product.php?slug=heavyweight-tee` | Detalle producto |
| `/philosophy.php` | Página de filosofía |
| `/admin/` | Panel de administración |

---

## Panel de Administración

Desde el panel admin puedes:

- ✅ Ver estadísticas (productos, pedidos, ingresos, suscriptores)
- ✅ **Agregar productos** con imágenes
- ✅ **Editar productos** (nombre, precio, descripción, fotos)
- ✅ **Eliminar productos**
- ✅ Ver **pedidos** realizados
- ✅ Ver **suscriptores** del newsletter

---

## Credenciales por Defecto

| Campo | Valor |
|-------|-------|
| Usuario Admin | `admin` |
| Contraseña | `admin123` |

⚠️ **CAMBIA ESTAS CREDENCIALES** inmediatamente después de instalar.

---

## Soporte

Tecnologías utilizadas:
- PHP 8.x
- MySQL 5.7+
- HTML5, CSS3, JavaScript (Vanilla)
- Diseño responsive (mobile-first)

Compatible con:
- ✅ Namecheap Shared Hosting
- ✅ cPanel
- ✅ Cualquier hosting con PHP + MySQL

---

## Próximos Pasos Recomendados

1. Subir tus propias fotos de productos desde el panel admin
2. Configurar Stripe para pagos reales
3. Personalizar los textos según tu marca
4. Configurar SSL (HTTPS) en Namecheap
5. Agregar tu dominio personalizado

---

**LXI - La Armadura del Gladiador Moderno**
