    <!-- Cart Overlay -->
    <div class="cart-overlay"></div>
    
    <!-- Cart Drawer -->
    <div class="cart-drawer" data-testid="cart-drawer">
        <div class="cart-header">
            <h2 class="cart-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--lxi-accent-gold);">
                    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
                YOUR ARMOR
            </h2>
            <button class="cart-close" aria-label="Close cart">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
        
        <div class="cart-progress">
            <p>Faltan <span>$150.00</span> para envío gratis</p>
            <div class="progress-bar">
                <div class="progress-bar-fill" style="width: 0%;"></div>
            </div>
        </div>
        
        <div class="cart-items">
            <div class="cart-empty">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                    <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <path d="M16 10a4 4 0 0 1-8 0"></path>
                </svg>
                <p>Tu armadura está vacía.</p>
            </div>
        </div>
        
        <div class="cart-footer">
            <div class="cart-subtotal">
                <span>SUBTOTAL</span>
                <span>$0.00</span>
            </div>
            
            <div class="gold-divider" style="margin-bottom: 16px;"></div>
            
            <button class="btn btn-gold-fill cart-checkout-btn" data-testid="checkout-button" onclick="proceedToCheckout()" disabled style="opacity: 0.5;">
                PROCEED TO ARMOR
            </button>
            
            <div class="trust-badges">
                <div class="trust-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                    <span>Secure</span>
                </div>
                <div class="trust-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                    </svg>
                    <span>Printful</span>
                </div>
                <div class="trust-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    </svg>
                    <span>Protected</span>
                </div>
            </div>
        </div>
    </div>
