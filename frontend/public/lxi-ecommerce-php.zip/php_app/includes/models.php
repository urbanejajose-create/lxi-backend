<?php
require_once __DIR__ . '/config.php';

class Product {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    public function getAll($category = null) {
        $sql = "SELECT * FROM products WHERE active = 1";
        $params = [];
        
        if ($category && $category !== 'ALL') {
            $sql .= " AND category = ?";
            $params[] = $category;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function getBySlug($slug) {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE slug = ? AND active = 1");
        $stmt->execute([$slug]);
        return $stmt->fetch();
    }
    
    public function getById($id) {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO products (slug, name, category, tag, price, description, long_description, sizes, 
                                  material_details, embroidery_details, sizing_details, shipping_details,
                                  image1, image2, image3)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([
            $data['slug'],
            $data['name'],
            $data['category'],
            $data['tag'] ?? '',
            $data['price'],
            $data['description'] ?? '',
            $data['long_description'] ?? '',
            $data['sizes'] ?? 'S,M,L,XL',
            $data['material_details'] ?? '',
            $data['embroidery_details'] ?? '',
            $data['sizing_details'] ?? '',
            $data['shipping_details'] ?? '',
            $data['image1'] ?? null,
            $data['image2'] ?? null,
            $data['image3'] ?? null
        ]);
    }
    
    public function update($id, $data) {
        $fields = [];
        $values = [];
        
        $allowedFields = ['name', 'category', 'tag', 'price', 'description', 'long_description', 
                         'sizes', 'material_details', 'embroidery_details', 'sizing_details', 
                         'shipping_details', 'image1', 'image2', 'image3', 'active'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $fields[] = "$field = ?";
                $values[] = $data[$field];
            }
        }
        
        if (empty($fields)) return false;
        
        $values[] = $id;
        $sql = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($values);
    }
    
    public function delete($id) {
        $stmt = $this->db->prepare("UPDATE products SET active = 0 WHERE id = ?");
        return $stmt->execute([$id]);
    }
    
    public function getCategories() {
        $stmt = $this->db->query("SELECT DISTINCT category FROM products WHERE active = 1");
        return array_column($stmt->fetchAll(), 'category');
    }
}

class Newsletter {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    public function subscribe($email) {
        try {
            $stmt = $this->db->prepare("INSERT INTO newsletter_subscribers (email) VALUES (?)");
            return $stmt->execute([$email]);
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                return false; // Duplicate email
            }
            throw $e;
        }
    }
    
    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM newsletter_subscribers ORDER BY subscribed_at DESC");
        return $stmt->fetchAll();
    }
}

class Order {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    public function create($sessionId, $items, $amount) {
        $stmt = $this->db->prepare("
            INSERT INTO orders (session_id, items, total_amount, status, payment_status)
            VALUES (?, ?, ?, 'initiated', 'pending')
        ");
        return $stmt->execute([$sessionId, json_encode($items), $amount]);
    }
    
    public function updateStatus($sessionId, $status, $paymentStatus) {
        $stmt = $this->db->prepare("
            UPDATE orders SET status = ?, payment_status = ? WHERE session_id = ?
        ");
        return $stmt->execute([$status, $paymentStatus, $sessionId]);
    }
    
    public function getBySessionId($sessionId) {
        $stmt = $this->db->prepare("SELECT * FROM orders WHERE session_id = ?");
        $stmt->execute([$sessionId]);
        return $stmt->fetch();
    }
    
    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM orders ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }
}

class Admin {
    private $db;
    
    public function __construct() {
        $this->db = getDB();
    }
    
    public function authenticate($username, $password) {
        $stmt = $this->db->prepare("SELECT * FROM admin_users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && verifyPassword($password, $user['password'])) {
            return $user;
        }
        return false;
    }
    
    public function createAdmin($username, $password, $email) {
        $stmt = $this->db->prepare("
            INSERT INTO admin_users (username, password, email) VALUES (?, ?, ?)
        ");
        return $stmt->execute([$username, hashPassword($password), $email]);
    }
    
    public function updatePassword($id, $newPassword) {
        $stmt = $this->db->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
        return $stmt->execute([hashPassword($newPassword), $id]);
    }
}
